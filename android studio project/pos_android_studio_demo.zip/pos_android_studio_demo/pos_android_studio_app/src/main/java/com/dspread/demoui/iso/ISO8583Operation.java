//package com.dspread.demoui.iso;
//
//import android.util.Log;
//
//import com.dspread.demoui.utils.TLV;
//import com.dspread.demoui.utils.TLVParser;
//
//import com.dspread.demoui.utils.Utils;
//import com.m8583.message.Field11;
//import com.m8583.message.Field12;
//import com.m8583.message.Field13;
//import com.m8583.message.Field14;
//import com.m8583.message.Field18;
//import com.m8583.message.Field2;
//import com.m8583.message.Field22;
//import com.m8583.message.Field23;
//import com.m8583.message.Field25;
//import com.m8583.message.Field26;
//import com.m8583.message.Field3;
//import com.m8583.message.Field32;
//import com.m8583.message.Field35;
//import com.m8583.message.Field4;
//import com.m8583.message.Field41;
//import com.m8583.message.Field42;
//import com.m8583.message.Field49;
//import com.m8583.message.Field52;
//import com.m8583.message.Field53;
//import com.m8583.message.Field55;
//import com.m8583.message.Field59;
//import com.m8583.message.Field60;
//import com.m8583.message.Field62ES;
//import com.m8583.message.Field632;
//import com.m8583.message.Field64;
//import com.m8583.message.Message8583;
//import com.m8583.message.MessageHeader;
//import com.m8583.message.MessageType;
//import com.m8583.message.Tpdu;
//
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.List;
//
///**
// * Created by dsppc11 on 2019/6/17.
// */
//
//public class ISO8583Operation {
//
//
//    private static String str = "60 00 03 00 00 " +
//            "60 31 00 31 07 30 " +
//            "02 00 " +
//            "30 20 04 C0 20 C0 98 11 " +
//            "00 00 00 " +
//            "00 00 00 00 00 01 " +
//            "00 03 49 " +
//            "02 10 " +
//            "00 " +
//            "12 " +
//            "30 62 25 82 21 12 99 63 01 5D 15 11 10 10 00 00 " +
//            "35 36 38 35 32 33 31 34 " +
//            "32 33 35 32 31 34 35 32 36 38 35 39 32 33 36 " +
//            "31 35 36 " +
//            "C6 24 83 4D 36 7E 9E 9E " +
//            "20 00 00 00 00 00 00 00 " +
//            "00 13 22 00 00 08 00 05 00 " +
//            "36 37 41 32 32 39 39 41";
//
//    private static Message8583 buildMSRMsg() {
//        Message8583 m = new Message8583(); // 3,4,11,22,25,26,35,36,41,42,49,52,53,60,64
//
//        Tpdu tpdu = new Tpdu();
//        tpdu.init();
//        tpdu.setTpdnId(60);
//        tpdu.setDestAddr(2);
//        tpdu.setSrcAddr(0);
//
//
//        MessageHeader msgHeader = new MessageHeader();
//        msgHeader.init();
//        msgHeader.setAppType(60);
//        msgHeader.setSoftwareVersion(31);
//        msgHeader.setReserved(313002);
//
//
//        m.setField(tpdu);
//        m.setField(msgHeader);
//
//        MessageType mt = new MessageType();
//        mt.setValue((long) 200);
//        m.setField(mt);
//
//        Field2 f2 = new Field2();
//        f2.setValue("4514617501631156");
//        m.setField(f2);
//
//        Field3 f3 = new Field3();
//        f3.setValue(100);
//        m.setField(f3);
//
//        Field4 f4 = new Field4();// amount
//        f4.setValue(100);
//        m.setField(f4);
//
//
//        Field11 f11 = new Field11();// System Trace Audit Number
//        f11.setValue(100);
//        m.setField(f11);
//        String terminalTime = new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime());
//
//        Field12 f12 = new Field12();// System Trace Audit Number
//        f12.setValue(Long.parseLong(terminalTime.substring(8,14)));
//        m.setField(f12);
//
//        Field13 f13 = new Field13();// System Trace Audit Number
//        f13.setValue(Long.parseLong(terminalTime.substring(4,8)));
//        m.setField(f13);
//
//
//        Field32 f32 = new Field32();
//        f32.setValue(123456789);
//        m.setField(f32);
//
//        String str35 = "6225260006685453D1011106";
//
//        Field35 f35 = new Field35();
//        f35.setValue(str35);
//        f35.setLength(str35.length());
//        m.setField(f35);
//
//
//        String merchid = "800000000100361";
//        String terminalid = "17100001000020000511";
//
//
//        Field41 f41 = new Field41();
//        f41.setValue(terminalid);
//        m.setField(f41);
//
//        Field42 f42 = new Field42();
//        f42.setValue(merchid);
//        m.setField(f42);
//
//        Field49 f49 = new Field49();
//        f49.setValue("156");
//        m.setField(f49);
//
//
//        Field52 f52 = new Field52();
//        f52.setValue("111111");
//        m.setField(f52);
//
//
//        Field53 f53 = new Field53();
//        f53.setPinFormat((byte) 2);// 带主账号信息
//        f53.setEncryptionMethod((byte) 6);// 双倍长密钥算法
//        m.setField(f53);
//
//
//        Field59 f59 = new Field59();
//        f59.setValue("dspreadmpos");
//        m.setField(f59);
//
//
//        Field62ES f62es = new Field62ES();
//        byte[] sign = new byte[]{1,1,1,1,11,1,1};
//        f62es.setValue(sign);
//        m.setField(f62es);
//
//
//        Field64 f64 = new Field64();
//        f64.setValue("00");
//        m.setField(f64);
//
//        return m;
//    }
//
//
//    private static Message8583 buildSaleICCMsg(String tlv) {
//        tlv = "5A0A6214672500000000056F5F24032307315F25031307085F2A0201565F34010182027C008407A00000033301018E0C000000000000000002031F009505088004E0009A031406179C01009F02060000000000019F03060000000000009F0702AB009F080200209F0902008C9F0D05D86004A8009F0E0500109800009F0F05D86804F8009F101307010103A02000010A010000000000CE0BCE899F1A0201569F1E0838333230314943439F21031826509F2608881E2E4151E527899F2701809F3303E0F8C89F34030203009F3501229F3602008E9F37042120A7189F4104000000015A0A6214672500000000056F5F24032307315F25031307085F2A0201565F34010182027C008407A00000033301018E0C000000000000000002031F00";
//        String[] tlvStrArr = {"5A","9F02","9A","5F34","5F2A"};
//
//        List<TLV> parse = TLVParser.parse(tlv);
//
//        Message8583 m = new Message8583(); // 2,3,4,11,14,22,23,25,26,35,41,42,49,52,53,55,60,64
//        Tpdu tpdu = new Tpdu();
//        tpdu.init();
//        tpdu.setTpdnId(60);
//        tpdu.setDestAddr(2);
//        tpdu.setSrcAddr(0);
//
//
//        MessageHeader msgHeader = new MessageHeader();
//        msgHeader.init();
//        msgHeader.setAppType(60);
//        msgHeader.setSoftwareVersion(31);
//        msgHeader.setReserved(313002);
//
//
//        m.setField(tpdu);
//        m.setField(msgHeader);
//
//
//
//        MessageType mt = new MessageType();
//        mt.setValue((long) 200);
//        m.setField(mt);
//
//        TLV tlv0 = TLVParser.searchTLV(parse, tlvStrArr[0]);
//        Field2 f2 = new Field2();
//        f2.setValue(tlv0.value.substring(0,tlv0.value.length()-1));
//        m.setField(f2);
//
//        Field3 f3 = new Field3();
//        f3.setValue(0);
//        m.setField(f3);
//
//        TLV tlv1 = TLVParser.searchTLV(parse, tlvStrArr[1]);
//
//        Field4 f4 = new Field4();// amount
//        f4.setValue(Long.parseLong(tlv1.value));
//        m.setField(f4);
//
//
//        Field11 f11 = new Field11();// System Trace Audit Number
//        f11.setValue(100);
//        m.setField(f11);
//
//        TLV tlv2 = TLVParser.searchTLV(parse, tlvStrArr[2]);
//
//        Field14 f14 = new Field14();
//        f14.setValue(Long.parseLong(tlv2.value.substring(0,4)));
//        m.setField(f14);
//
//        Field18 f18 = new Field18();
//        f18.setValue(11);
//        m.setField(f18);
//
//        Field22 f22 = new Field22();
//        f22.setValue("510");
//        m.setField(f22);
//
//        TLV tlv3 = TLVParser.searchTLV(parse, tlvStrArr[3]);
//        Field23 f23 = new Field23();
//        f23.setValue(Long.parseLong(tlv3.value));
//        m.setField(f23);
//
//        Field25 f25 = new Field25();
//        f25.setValue(0);
//        m.setField(f25);
//
//        Field26 f26 = new Field26();
//        f26.setValue((long) 12);
//        m.setField(f26);
//
//        String str35 = "6225260006685453D1011106";
//
//        Field35 f35 = new Field35();
//        f35.setValue(str35);
//        f35.setLength(str35.length());
//        m.setField(f35);
//
//
//        String merchid = "800000000100361";
//        String terminalid = "17100001000020000511";
//
//
//        Field41 f41 = new Field41();
//        f41.setValue(terminalid);
//        m.setField(f41);
//
//        Field42 f42 = new Field42();
//        f42.setValue(merchid);
//        m.setField(f42);
//
//        TLV tlv4 = TLVParser.searchTLV(parse, tlvStrArr[4]);
//
//        Field49 f49 = new Field49();
//        f49.setValue(tlv4.value);
//        m.setField(f49);
//
//
//        Field53 f53 = new Field53();
//        f53.setPinFormat((byte) 2);// 带主账号信息
//        f53.setEncryptionMethod((byte) 6);// 双倍长密钥算法
//        m.setField(f53);
//
//
//        Field62ES f62es = new Field62ES();
//        byte[] sign = new byte[]{1,1,1,1,11,1,1};
//        f62es.setValue(sign);
//        m.setField(f62es);
//
//
//        Field64 f64 = new Field64();
//        f64.setValue("00");
//        m.setField(f64);
//
//        return m;
//    }
//
//
//    public static void main(String[] args) throws InterruptedException {
//        Message8583 message8583 = buildMSRMsg();
//        byte[] bytes = message8583.toBytes();
//        System.out.println(Utils.bytes2Hex(bytes));
//
//        Message8583 message85831 = buildSaleICCMsg("");
//        byte[] byt = message85831.toBytes();
//        System.out.println(Utils.bytes2Hex(byt));
//
//    }
//
//
//    String data = "008A" +
//            "6000020000" +
//            "603100313002" +
//            "0200" +
//            "7038000120C09825" +
//            "164514617501631156" +
//            "000100" +
//            "000000000100" +
//            "000100" +
//            "164521" +
//            "0617" +
//            "09123456789" +
//            "0246225260006685453D1011106" +
//            "3137313030303031" +
//            "303030303230303030353131" +
//            "383030303030303030313030333631" +
//            "313536" +
//            "11111126" +
//            "0000000000000000" +
//            "11647370726561646D706F73" +
//            "000701010101" +
//            "0B010100";
//
//}
