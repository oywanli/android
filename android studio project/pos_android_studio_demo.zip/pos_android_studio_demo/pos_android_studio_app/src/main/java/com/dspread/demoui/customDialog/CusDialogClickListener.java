package com.dspread.demoui.customDialog;

import android.app.Dialog;

/**
 * Created by dell on 2018/1/12.
 */

public interface CusDialogClickListener
{
    boolean buttonOk(Dialog dialog);
    void buttonCancel(Dialog dialog);
}