package com.dspread.demoui;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import com.dspread.demoui.QPOSUtil;

public class DUKPT {
    public enum KeyType {
        TDEA2,
        TDEA3,
        AES128,
        AES192,
        AES256
    }

    ;

    public enum DerivationPurpose {
        Initial_Key,
        Derivation_or_Working_Key
    }

    ;

    enum KeyUsage {
        Key_Encryption_Key,
        PIN_Encryption,
        Message_Authentication_generation,
        Message_Authentication_verification,
        Message_Authentication_both_ways,
        Data_Encryption_encrypt,
        Data_Encryption_decrypt,
        Data_Encryption_both_ways,
        Key_Derivation,
        Key_Derivation_Initial_Key
    }

    ;

    static int Key_Length(KeyType keyType) {
        if (keyType == KeyType.TDEA2) {
            return 128;
        } else if (keyType == KeyType.TDEA3) {
            return 192;
        } else if (keyType == KeyType.AES128) {
            return 128;
        } else if (keyType == KeyType.AES192) {
            return 192;
        } else if (keyType == KeyType.AES256) {
            return 256;
        }

        return 0;
    }

    private static byte[] aes_ecb_block_encrypt(byte[] key, byte[] input) {
        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"));
            return cipher.doFinal(input);
        } catch (Exception e) {
        }
        return null;
    }


    private static byte[] Derive_Key(byte[] derivationKey, KeyType keyType, byte[] derivationData) {
        int L = Key_Length(keyType);
        int n = (L + 127) / 128;
        byte[] result = new byte[32];

        for (byte i = 1; i <= n; i++) {
            // Set the value of the derivation data key block counter field equal to
            // the block count being derived.
            // First block is 0x01, second block is 0x02.
            derivationData[1] = i;
            byte[] ret = aes_ecb_block_encrypt(derivationKey, derivationData);
            System.arraycopy(ret, 0, result, (i - 1) * 16, 16);
        }

        byte[] derivedKey = new byte[L / 8];
        System.arraycopy(result, 0, derivedKey, 0, L / 8);
        return derivedKey;
    }

    private static void Create_Derivation_Data(DerivationPurpose derivationPurpose, KeyUsage keyUsage,
                                       KeyType derivedKeyType, byte[] initialKeyID,
                                       long counter, byte[] DerivationData) {
        // Set Version ID of the table structure.
        DerivationData[0] = 0x01; // version 1
        // set Key Block Counter
        DerivationData[1] = 0x01; // 1 for first block, 2 for second, etc.
        // set Key Usage Indicator
        if (keyUsage == KeyUsage.Key_Encryption_Key) {
            DerivationData[2] = 0x00;
            DerivationData[3] = 0x02;
        } else if (keyUsage == KeyUsage.PIN_Encryption) {
            DerivationData[2] = 0x10;
            DerivationData[3] = 0x00;
        } else if (keyUsage == KeyUsage.Message_Authentication_generation) {
            DerivationData[2] = 0x20;
            DerivationData[3] = 0x00;
        } else if (keyUsage == KeyUsage.Message_Authentication_verification) {
            DerivationData[2] = 0x20;
            DerivationData[3] = 0x01;
        } else if (keyUsage == KeyUsage.Message_Authentication_both_ways) {
            DerivationData[2] = 0x20;
            DerivationData[3] = 0x02;
        } else if (keyUsage == KeyUsage.Data_Encryption_encrypt) {
            DerivationData[2] = 0x30;
            DerivationData[3] = 0x00;
        } else if (keyUsage == KeyUsage.Data_Encryption_decrypt) {
            DerivationData[2] = 0x30;
            DerivationData[3] = 0x01;
        } else if (keyUsage == KeyUsage.Data_Encryption_both_ways) {
            DerivationData[2] = 0x30;
            DerivationData[3] = 0x02;
        } else if (keyUsage == KeyUsage.Key_Derivation) {
            DerivationData[2] = (byte) 0x80;
            DerivationData[3] = 0x00;
        } else if (keyUsage == KeyUsage.Key_Derivation_Initial_Key) {
            DerivationData[2] = (byte) 0x80;
            DerivationData[3] = 0x01;
        }

        // set Algorithm Indicator and key size
        if (derivedKeyType == KeyType.TDEA2) {
            DerivationData[4] = 0x00;
            DerivationData[5] = 0x00;
        } else if (derivedKeyType == KeyType.TDEA3) {
            DerivationData[4] = 0x00;
            DerivationData[5] = 0x01;
        } else if (derivedKeyType == KeyType.AES128) {
            DerivationData[4] = 0x00;
            DerivationData[5] = 0x02;
        } else if (derivedKeyType == KeyType.AES192) {
            DerivationData[4] = 0x00;
            DerivationData[5] = 0x03;
        } else if (derivedKeyType == KeyType.AES256) {
            DerivationData[4] = 0x00;
            DerivationData[5] = 0x04;
        }

        // set length of key material being generated
        if (derivedKeyType == KeyType.TDEA2) {
            DerivationData[6] = 0x00;
            DerivationData[7] = (byte) 0x80;
        } else if (derivedKeyType == KeyType.TDEA3) {
            DerivationData[6] = 0x00;
            DerivationData[7] = (byte) 0xC0;
        } else if (derivedKeyType == KeyType.AES128) {
            DerivationData[6] = 0x00;
            DerivationData[7] = (byte) 0x80;
        } else if (derivedKeyType == KeyType.AES192) {
            DerivationData[6] = 0x00;
            DerivationData[7] = (byte) 0xC0;
        } else if (derivedKeyType == KeyType.AES256) {
            DerivationData[6] = 0x01;
            DerivationData[7] = 0x00;
        }

        if (derivationPurpose == DerivationPurpose.Initial_Key) {
            System.arraycopy(initialKeyID, 0, DerivationData, 8, 8);
            //memcpy(&DerivationData[8], initialKeyID, 8);
        } else if (derivationPurpose == DerivationPurpose.Derivation_or_Working_Key) {
            System.arraycopy(initialKeyID, 4, DerivationData, 8, 4);
            //memcpy(&DerivationData[8], &initialKeyID[4], 4);
            DerivationData[12] = (byte) ((counter >> 24) & 0xFF);
            DerivationData[13] = (byte) ((counter >> 16) & 0xFF);
            DerivationData[14] = (byte) ((counter >> 8) & 0xFF);
            DerivationData[15] = (byte) (counter & 0xFF);
        }
    }

    private static byte[] Derive_Initial_Key(byte[] BDK, KeyType keyType, byte[] initialKeyID)
    {
        byte[] derivationData = new byte[16];
        Create_Derivation_Data(DerivationPurpose.Initial_Key,
                KeyUsage.Key_Derivation_Initial_Key,
                keyType, initialKeyID, 0,
                derivationData);
        return Derive_Key(BDK, keyType, derivationData);
    }

    static byte[] Host_Derive_Working_Key(byte[] BDK, KeyType deriveKeyType,
        KeyUsage workingKeyUsage,KeyType workingKeyType,
        byte[] initialKeyID, long transactionCounter)
    {
        byte[] derivationKey;
        byte[] derivationData = new byte[16];

        derivationKey = Derive_Initial_Key(BDK, deriveKeyType, initialKeyID);

        // set the most significant bit to one and all other bits to zero
        long mask = 1;
        mask <<= 31;
        long workingCounter = 0;

        // calculate current derivation key from initial key
        while (mask > 0) {
            if ((mask & transactionCounter) != 0) {
                workingCounter = workingCounter | mask;
                Create_Derivation_Data(DerivationPurpose.Derivation_or_Working_Key,
                        KeyUsage.Key_Derivation, deriveKeyType, initialKeyID,
                        workingCounter, derivationData);
                derivationKey = Derive_Key(derivationKey, deriveKeyType,
                        derivationData);
            }
            mask = mask >> 1;
        }

        // derive working key from current derivation key
        Create_Derivation_Data(DerivationPurpose.Derivation_or_Working_Key, workingKeyUsage,
                workingKeyType, initialKeyID,
                transactionCounter, derivationData);
        return Derive_Key(derivationKey, workingKeyType, derivationData);
    }

    private static byte[] Host_Derive_Working_Key(byte[] BDK, KeyType deriveKeyType,
                                          KeyUsage workingKeyUsage,KeyType workingKeyType,
                                          byte[] initialKeyID, byte[] ksn) {
        long counter = (ksn[11] & 0xFF) + ((ksn[10] & 0xFF) << 8) + ((ksn[9] & 0xFF) << 16) + ((ksn[8] & 0xFF) << 24);
        return Host_Derive_Working_Key(BDK, deriveKeyType, workingKeyUsage, workingKeyType,
                initialKeyID, counter);
    }


    public DUKPT(byte[] bdk,byte[] kid) {
        mBdk = bdk;
        mKid = kid;
    }

    public DUKPT() {
        mBdk = QPOSUtil.HexStringToByteArray(BDK);
        mKid = QPOSUtil.HexStringToByteArray(INITIAL_KEY_ID);
    }

    public byte[] deriveTransactionDataKey(byte[] ksn) {
        byte[] workingKey =  Host_Derive_Working_Key(mBdk, KeyType.AES128, KeyUsage.Data_Encryption_encrypt, KeyType.AES128,
                mKid, ksn);

        long counter = (ksn[11] & 0xFF) + ((ksn[10] & 0xFF) << 8) + ((ksn[9] & 0xFF) << 16) + ((ksn[8] & 0xFF) << 24);
        if (java.util.Arrays.equals(mBdk, QPOSUtil.HexStringToByteArray(BDK)) &&
                java.util.Arrays.equals(mKid, QPOSUtil.HexStringToByteArray(INITIAL_KEY_ID))) {
            for (int i = 0; i < testVector.length; i++) {
                if (testVector[i].counter == counter) {
                    if (!java.util.Arrays.equals(workingKey, QPOSUtil.HexStringToByteArray(testVector[i].workKey))) {

                        return null;

                    }
                    break;
                }
            }
        }

        return workingKey;
    }

    public byte[] deriveESLKey(byte[] ksn) {
        return Host_Derive_Working_Key(mBdk, KeyType.AES128, KeyUsage.Data_Encryption_encrypt, KeyType.AES128,
                mKid, ksn);
    }

    // test working keys for Data_Encryption_both_ways
    static private TestKey testVector[] = {
            new TestKey(1, "A35C412EFD41FDB98B69797C02DCD08F"),
            new TestKey(2, "D639514AA33AC43AD9229E433D6D4E5B"),
            new TestKey(3, "EF17F6AB45B4820C93A3DCB21BC491AD"),
            new TestKey(4, "B3BD44C08BB6BA27C3BB4711D7D70387"),
            new TestKey(5, "CA02DF6F30B39E14BD0B4A30E460920F"),
            new TestKey(131070, "8E4E5D5E0F01C54F01F4ACA1C8F8EDCE"),
            new TestKey(131071, "D18ACA30B4D63DB61CE474D3F57733D3"),
            new TestKey(131072, "13361208975755318FE7AE28C9616014")
    };


    static private class TestKey {
        public TestKey(int counter, String workKey) {
            this.counter = counter;
            this.workKey = workKey;
        }

        public int counter;
        public String workKey;
    }

    static private String BDK = "FEDCBA9876543210F1F1F1F1F1F1F1F1";
    static private String INITIAL_KEY_ID = "1234567890123456";

    private byte[] mBdk;
    private byte[] mKid;
}
