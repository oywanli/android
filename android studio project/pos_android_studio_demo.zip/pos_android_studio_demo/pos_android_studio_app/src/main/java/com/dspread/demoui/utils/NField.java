package com.dspread.demoui.utils;


abstract public class NField {
	private long value = -1;
	
	protected byte[] getBytes(int byteLen) {
		byte[] data = new byte[byteLen];
		
		int ret = Utils.long2Bcd(value, data, 0, byteLen);
		if (ret < 0) {
			data = null;
		}
		
		return data;
	}
	
	protected int consume(byte[] data, int offset, int length) {
		value = Utils.bcd2Long(data, offset, length);
		if (value < 0) {
			return -100;
		}
		
		return length;
	}
	
	protected int initFixed(byte[] data, int offset, int fieldlen) {
		int len = (fieldlen + 1) >> 1;
		if (data.length - offset < len) {
			return -200;
		}
		
		int ret = consume(data, offset, len);
		return ret;
	}

	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}
}
