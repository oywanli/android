package com.dspread.demoui.iso;



import com.dspread.demoui.iso.Util.ByteUtil;
import com.dspread.demoui.iso.bean.Bean8583;

import java.lang.reflect.InvocationTargetException;
import java.util.BitSet;

public class Analysis8583 {

	/**
	 * 计算前64位位图信息
	 * 
	 * @param bitMap
	 */
	public static BitSet getMapInfo(String bitMap) {
		// 将位图中每一位都解析出来 判断到底有哪些域
		BitSet bitSet = ByteUtil.hexStringToBitSet(bitMap);
		System.out.println(String.format("位图：%s", bitMap));
		System.out.print("存在位图域：");
		for (int i = 0; i < bitSet.size(); i++) {
			if (bitSet.get(i)) {
				if (i == 0) {
					System.out.println("===============存在第二位图===============");
				} else {
					System.out.print(String.format(" %d", i + 1));
				}
			}
		}
		System.out.println();
		return bitSet;
	}
	
	public static Bean8583 analysisMsg(String str){
		byte[] msg = ByteUtil.strToBCDBytes(str);
		// 解码POS发送到POSP的报文			

		Decoding8583 reqMsg = new Decoding8583(msg);
		return reqMsg.getResMes();
	}

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		//报文格式：交易码+位图+正文
		String msg8583 = "02 00 70 20 00 00 20 C0 82 00 19 06 20 51 32 00 00 00 02 61 20 60 00 00 00 00 00 02 00 00 00 00 73 37 06 20 51 32 00 00 00 02 61 20 d1 91 12 01 00 00 00 00 00 30 30 30 30 31 31 31 31 31 30 32 32 35 30 31 35 33 31 31 31 31 31 31 01 56 00 44 9f 26 08 92 b6 ae 9a 9b 10 2e d6 9f 27 01 80 9f 10 13 07 01 01 03 a0 a0 10 01 0a 01 00 00 00 10 37 51 3a 22 be";
		  msg8583 = msg8583.replaceAll(" ", "");
//		String msg8583 = "006208002020000000C0003292100030303030303030303430323037373135383134303030310048303030303030303030303030303030303030303030303030303030303030303039373235313631383132333632323030001200000001003600023031";
//		msg8583 = msg8583.substring(4);
//		System.out.println(String.format("交易码：%s", msg8583.substring(0, 4)));
//		// 根据第一位来判断是否有位图2 1有 0没有
		String bitMap = msg8583.substring(4, 20);
//		//目前只处理64域的不考虑128域的
		getMapInfo(bitMap);
		Bean8583 bean8583 = analysisMsg(msg8583);
		System.out.println(bean8583.toString());
	}

}
