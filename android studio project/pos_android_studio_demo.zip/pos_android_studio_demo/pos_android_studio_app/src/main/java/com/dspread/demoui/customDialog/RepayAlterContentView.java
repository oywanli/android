package com.dspread.demoui.customDialog;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.dspread.demoui.R;

import java.util.regex.Pattern;


/**
 * Created by dell on 2018/1/12.
 */

public class RepayAlterContentView extends RelativeLayout {
    private View root;
    TextView tvMouth;
    EditText etMoney;
    private Context mContext;
    private LinearLayout botCon;

    public RepayAlterContentView(Context context) {
        super(context);

        initView(context);
        initData();
    }


    public RepayAlterContentView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView(context);
        initData();
    }

//    @Override
//    protected void onFinishInflate() {
//        super.onFinishInflate();
//        initView(mContext);
//        initData();
//    }

    private void initData() {
    }

    public String getMouth(){
        if (tvMouth!=null){
            return tvMouth.getText().toString();
        }
        return "";
    }

    public String getMoney(){
        if (etMoney!=null){
            return etMoney.getText().toString();
        }
        return "";
    }

//    public void setMouth(String mouth){
//        if (tvMouth!=null){
//            if (!TextUtils.isEmpty(mouth)){
//                tvMouth.setText(mouth);
//                tvMouth.setTextColor(mContext.getResources().getColor(R.color.app_primary_color));
//            }
//        }
//    }


    Animation translateAnimation;

    public void etShake(){
        if (translateAnimation == null){
                translateAnimation = new TranslateAnimation(0, 10, 0, 0);
        }
        translateAnimation.setInterpolator(new CycleInterpolator(4));
        translateAnimation.setDuration(500);
        etMoney.startAnimation(translateAnimation);
    }


    public void releaseRes(){
        if (translateAnimation!=null){
            translateAnimation.cancel();
            translateAnimation = null;
        }
    }



    private void initView(Context context) {
        mContext = context;
        root = LayoutInflater.from(mContext).inflate(R.layout.repay_alter_content_view, null, false);

        etMoney = (EditText) root.findViewById(R.id.et_money);
        TransformationMethod method =  PasswordTransformationMethod.getInstance();
        etMoney.setTransformationMethod(method);

        etMoney.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String string = s.toString();
                if (!TextUtils.isEmpty(string) && string.contains(".")) {
                    int i = string.indexOf(".");
                    if (i == 0) {
                        s.delete(0, string.length());
                    }
                }
                if (!TextUtils.isEmpty(string) && string.length()>1){
                    String substring = string.substring(0, 2);
                    String sub = substring.substring(0, 1);
                    String str = substring.substring(1, 2);
                    Pattern p = null;
                    if (sub.equals("0")){
                        p = Pattern.compile("[0-9]*");   //除数字外的其他的
                        if (str.equals("."))
                            return;
                        if (p.matcher(str).matches()){
                            s.delete(0,1);
                            return;
                        }
                    }
                }
            }
        });
        etMoney.setFilters(new InputFilter[]{new CreAddInputFilter()});
//        botCon = ((LinearLayout) root.findViewById(R.id.bot_con));
//        botCon.requestFocus();
        addView(root);
    }

}
