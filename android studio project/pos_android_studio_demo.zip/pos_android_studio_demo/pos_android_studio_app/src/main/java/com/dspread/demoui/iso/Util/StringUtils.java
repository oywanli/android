package com.dspread.demoui.iso.Util;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class StringUtils {
	
	 /**
     * 判断数据是否为空,""及null都认为是空
     * @param str 字符串
     * @return true-为空,false-非空
     */
    public static boolean isEmpty(String str) {
        if (str == null || str.trim().length() == 0) {
            return true;
        }
        return false;
    }
	/**
	 * 字符串左补齐字符串(0)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillZeroLeft(String field, int len) {
		if(null==field){
			field="";
		}
		int fillLen = len - field.length();

		for (int i = 0; i < fillLen; i++) {
			field = "0" + field;
		}
		return field;
	}
	
	/**
	 * 非字符串左补齐字符串(0)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillZeroLeft(Object field, int len) {
		return fillZeroLeft(String.valueOf(field), len);
	}
	
	/**
	 * 字符串左补齐字符串(SPACE)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillSpaceLeft(String field, int len) {

		int fillLen = len - field.length();

		for (int i = 0; i < fillLen; i++) {
			field = " " + field;
		}
		return field;
	}
	
	/**
	 * 
	 * fillSpaceLeft(左补空格)
	 * @param content
	 * @param length
	 * @param type
	 * @return   
	 *		String  
	 * @exception   
	 * @since  1.0.0
	 */
	public static String fillSpaceLeft(String content, int length, int type) {
        if(content==null){
            content="";
        }
        int contentLen = content.length();
        if (contentLen >= length) {
            return content;
        } else {
            char[] dest = new char[length];
            Arrays.fill(dest, ' ');
            content.getChars(0, contentLen, dest, length - contentLen);
            return new String(dest);
        }
    }

	
	/**
	 * 非字符串左补齐字符串(SPACE)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillSpaceLeft(Object field, int len) {
		return fillZeroLeft(String.valueOf(field), len);
	}

	/**
	 * 字符串右补齐字符串(0)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillZeroRight(String field, int len) {
		if(null == field){
			field = "";
		}
		int fillLen = len - field.length();

		for (int i = 0; i < fillLen; i++) {
			field += "0";
		}
		return field;
	}
	/**
	 * 字符串右补齐字符串(0)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillZeroRight(Object field, int len) {
		return fillZeroRight(String.valueOf(field), len);
	}
	
	/**
	 * 字符串右补齐字符串(SPACE)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillSpaceRight(String field, int len) {
		int fillLen = len - field.length();

		for (int i = 0; i < fillLen; i++) {
			field += " ";
		}
		return field;
	}
	
	/**
	 * 字符串右补齐字符串(SPACE)
	 * 
	 * @param field
	 *            源字符串
	 * @param len
	 *            补齐后长度
	 * @return 返回补齐后的字符串
	 */
	public static String fillSpaceRight(Object field, int len) {
		return fillZeroRight(String.valueOf(field), len);
	}
	
	public static String stringToHexString(String strPart) {
		String hexString = "";
		for (int i = 0; i < strPart.length(); i++) {
			int ch = strPart.charAt(i);
			String strHex = Integer.toHexString(ch);
			hexString = hexString + strHex;
		}
		return hexString;
	}
	
	public static String formatResTranCode(String tranCode){
		String icode = (Integer.parseInt(tranCode)+10) + "";
		return StringUtils.fillZeroLeft(icode, 4);
	}

	private static String hexString = "0123456789ABCDEF";

	/**
	 * 
	 * encode(将字符串编码成16进制数字,适用于所有字符（包括中文）)
	 * @param str
	 * @return
	 * @throws UnsupportedEncodingException   
	 *		String  
	 * @exception   
	 * @since  1.0.0
	 */
	public static String encode(String str) throws UnsupportedEncodingException {
		// 根据默认编码获取字节数组
		byte[] bytes = str.getBytes("GBK");
		StringBuilder sb = new StringBuilder(bytes.length * 2);
		// 将字节数组中每个字节拆解成2位16进制整数
		for (int i = 0; i < bytes.length; i++) {
			sb.append(hexString.charAt((bytes[i] & 0xf0) >> 4));
			sb.append(hexString.charAt((bytes[i] & 0x0f) >> 0));
		}
		return sb.toString();
	}

	/**
	 * 
	 * decode(将16进制数字解码成字符串,适用于所有字符（包括中文）)
	 * @param bytes
	 * @return   
	 *		String  
	 * @throws Exception 
	 * @exception   
	 * @since  1.0.0
	 */
	public static String decode(String bytes,String encoding) {
		String result = "";
		ByteArrayOutputStream baos = new ByteArrayOutputStream(
				bytes.length() / 2);
		// 将每2位16进制整数组装成一个字节
		for (int i = 0; i < bytes.length(); i += 2)
			baos.write((hexString.indexOf(bytes.charAt(i)) << 4 | hexString
					.indexOf(bytes.charAt(i + 1))));
		try {
			if(null!=encoding){
				result =  new String(baos.toByteArray(),encoding);
			}else{
				result =  new String(baos.toByteArray());
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	 //  转化十六进制编码为字符串 
    public static String toStringHex(String s,String encoding) {
        byte[] baKeyword = new byte[s.length() / 2];
        for (int i = 0; i < baKeyword.length; i++) {
            try {
                baKeyword[i] = (byte) (0xff & Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            s = new String(baKeyword, encoding);//UTF-16le:Not 
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return s;
    }
    
	public static byte[] decode2byte(String bytes){
		ByteArrayOutputStream baos = new ByteArrayOutputStream(
				bytes.length() / 2);
		// 将每2位16进制整数组装成一个字节
		for (int i = 0; i < bytes.length(); i += 2)
			baos.write((hexString.indexOf(bytes.charAt(i)) << 4 | hexString
					.indexOf(bytes.charAt(i + 1))));
		return baos.toByteArray();
	}
	
	public static void main(String args[]) throws Exception{
//		System.out.println(Integer.toHexString(Integer.parseInt("14")));
		System.out.println(decode("CDF5CAE9E7F7","GBK"));
		System.out.println(toStringHex("CDF5CAE9E7F7","GBK"));
		System.out.println(encode("姚旭"));
	}
}
