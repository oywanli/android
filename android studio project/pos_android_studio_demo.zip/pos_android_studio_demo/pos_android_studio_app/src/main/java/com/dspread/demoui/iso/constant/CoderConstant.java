package com.dspread.demoui.iso.constant;

import java.util.HashMap;
import java.util.Map;

public class CoderConstant {
	/**
	 * 位图标志TRUE
	 */
	public static String BITSET_ONE = "1";
	/**
	 * 位图标志FALSE
	 */
	public static String BITSET_ZERO = "0";
	/**
	 * 16进制数组
	 */
	public static String[] hexStr = { "0", "1", "2", "3", "4", "5", "6", "7",
			"8", "9", "A", "B", "C", "D", "E", "F" };
	/**
	 * 16进制字符串
	 */
	public static String hexString = "0123456789ABCDEF";

	/**
	 * 16进制字符串对应的2进制字符串
	 */
	public static Map<String, String> hexMap = new HashMap<String, String>() {
		{
			put("0", "0000");
			put("1", "0001");
			put("2", "0010");
			put("3", "0011");
			put("4", "0100");
			put("5", "0101");
			put("6", "0110");
			put("7", "0111");
			put("8", "1000");
			put("9", "1001");
			put("A", "1010");
			put("B", "1011");
			put("C", "1100");
			put("D", "1101");
			put("E", "1110");
			put("F", "1111");
		}
	};
	
	/**
	 * 报文输入输出流缓冲区的大小
	 */
	public static final int READBUFF_SIZE = 1024;
}
