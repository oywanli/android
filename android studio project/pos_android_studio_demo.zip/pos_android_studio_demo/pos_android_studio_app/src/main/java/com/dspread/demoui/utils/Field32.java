package com.dspread.demoui.utils;


/* Acquiring Institution Identification Code; N..11(LLVAR) */
public class Field32 extends NField implements Field {
	private static final int MAXLEN = 11;
	private static final int LENLEN = 2;
	private static final int NUMBER = 32;

	private int dataLength = 0;

	@Override
	public byte[] toBytes() {
		if (dataLength <= 0) {
			return null;
		}

		int len = ((LENLEN + 1) >> 1) + ((dataLength + 1) >> 1);
		byte[] data = new byte[len];

		int p = 0;
		data[p++] = Utils.int2d2Bcd(dataLength);

		long v = getValue();
		if ((dataLength & 0x01) > 0) {
			v *= 10;
		}

		int ret = Utils.long2Bcd(v, data, p, (dataLength + 1) >> 1);
		if (ret < 0) {
			data = null;
		}

		return data;
	}

	@Override
	public int init(byte[] data, int offset) {
		int p = offset;
		int byteslen = (LENLEN + 1) >> 1;
		if ((data.length - p) < byteslen) {
			return -1;
		}

		int length = Utils.bcd2Int(data[p]);
		p += byteslen;
		byteslen = (length + 1) >> 1;
		int last = p + byteslen;
		if (data.length < last || length > MAXLEN) {
			return -2;
		}

		if (p >= last) {
			return p - offset;
		}

		int ret = initFixed(data, p, length);
		if (ret < 0) {
			return ret;
		}
		dataLength = length;

		p += ret;

		if ((length & 0x01) > 0) {
			setValue(getValue() / 10);
		}

		return p - offset;
	}

	@Override
	public int getType() {
		return NUMBER;
	}

	public static void main(String[] args) throws InterruptedException {
		Field32 f32 = new Field32();
		f32.setValue(1111);
		byte[] bytes = f32.toBytes();
	}

	}
