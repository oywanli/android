package com.dspread.demoui.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;

/**
 * Created by dsppc11 on 2019/3/21.
 */

public class BootUtils {

    public static Hashtable<String, String> readConStream(InputStream in, String filter) throws Exception {
        Hashtable<String, String> table = new Hashtable();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line = null;
            String preLine = null;
            boolean isMatch = false;
            boolean isMatchNew = false;
            while ((line = br.readLine()) != null) {
                if (line.contains("END")) {
                    break;
                }
                if (line.contains(";============="))
                    continue;
              if (!line.contains("=")){
                  table.put("device",line);
              }else {
                  String[] split = line.split("=");
                  if (split[0].contains("head_key")){
                      if (split[1].trim().equals(filter)){
                          isMatch = true;
                      }else {
                          preLine = line;
                      }
                  }

                  if (split[0].contains("new_head_key") && isMatch == false){
                      if (split[1].trim().equals(filter)){
                          String[] preHead = preLine.split("=");
                          table.put(preHead[0].trim(),preHead[1].trim());
                         isMatchNew = true;
                      }
                  }

                  if (isMatch || isMatchNew){
                      table.put(split[0].trim(),split[1].trim());
                  }

                  if ((isMatch || isMatchNew ) && split[0].contains("upgrade_type_select")){
                     break;
                  }

              }
            }
            return table;
        } catch (IOException var5) {
            throw new Exception("鍏\ue104挜鏁版嵁娴佽\ue1f0鍙栭敊锟�?");
        } catch (NullPointerException var6) {
            throw new Exception("鍏\ue104挜杈撳叆娴佷负锟�?");
        }
    }
}
