package com.dspread.demoui.utils;

import com.dspread.demoui.TRACE;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;





/*
*
* tlv:5F200D202020202020202020202020204F08A0000003330101015F24032412319F160F4243544553543132333435363738009F21031142259A031808039F02060000000011119F03060000000000009F34034203009F120A50424F432044454249549F0607A00000033301015F300202209F4E0F616263640000000000000000000000C40A621067FFFFFFFFF0474FC10A00000332100300E0008BC708B04EFFA147D84FB4C00A00000332100300E00074C28201983ABB68B0A87865BFCAC1FCD6D2794C9C293A667EA2E0DF8FE08658105DF18EE870CDE7714573245EF4F1509F4F7DD2D8AA3A0700570556BB30C5BB3AA0D95C26B9A7A1A0FE45CCCF939D7587D3DBDF3D1D96722F7F9F8C1E0077C89BA4D4D267F74A60CF65E1D66F62685B6E41C25BDAEA4F353EBF9021195824842693CB76733CDEBFC61C6E75F9A87DBB33181C301074FDD300028A1037B8372CE0943EFBA84C82D2448DD142941895136A46CF65F84DFC6A792F502D556DA84106584AFDE8A0838B45E8E1BDAE9747FDF91C10E9D7BC9C5EE15CF0A1746ADDB8F7CB96EA672B127B19FF06A733509B5A04F5BF31D1678C2E5951CABE67E34E97AD946B4DACF3CA500188625890BCA60D7D29A63ED9F6CAEE3369C4E5DC9C2F890200FF24986DD6931BB13FC145D46B1961888B9317263C22351F98796A4FF75CF2262797535D54FD7B58F24535286C3A0EFA9524EE642EB6818EED427F8A447244A883E73FB36AAFB72B2C8EF0829E086CC87E6005E3CBE4C7E3A79CBF339320342B547C4E6D256BB98F78FE9E9A5434EF4CAB734093CD0329667FF2FA

*
* */


public class TLVParser {
	
	public static List<TLV> parse(String tlv) {
		try {
			return getTLVList(hexToByteArray(tlv));
		} catch(Exception e) {
			return null;
		}
	}
	
	private static List<TLV> getTLVList(byte[] data) {
		int index = 0;
		
		ArrayList<TLV> tlvList = new ArrayList<TLV>();
		
		while(index < data.length) {
		
			byte[] tag;
			byte[] length;
			byte[] value;
			
			boolean isNested;
			if((data[index] & (byte)0x20) == (byte)(0x20)) {
				isNested = true;
				//复合结构
			} else {
				isNested = false;
			}
			
			if((data[index] & (byte)0x1F) == (byte)(0x1F)) {
				int lastByte = index + 1;
				while((data[lastByte] & (byte)0x80) == (byte)0x80) {
					++lastByte;
				}
				tag = new byte[lastByte - index + 1];
				System.arraycopy(data, index, tag, 0, tag.length);
				index += tag.length;
			} else {
				tag = new byte[1];
				tag[0] = data[index];
				++index;
				
				if(tag[0] == 0x00) {
					break;
				}
			}
			
			if((data[index] & (byte)0x80) == (byte)(0x80)) {
				int n = (data[index] & (byte)0x7F) + 1;
				length = new byte[n];
				System.arraycopy(data, index, length, 0, length.length);
				index += length.length;
			} else {
				length = new byte[1];
				length[0] = data[index];
				++index;
			}
			
			int n = getLengthInt(length);
			value = new byte[n];
			System.arraycopy(data, index, value, 0, value.length);
			index += value.length;
			
			TLV tlv = new TLV();
			tlv.tag = toHexString(tag);
			tlv.length = toHexString(length);
			tlv.value = toHexString(value);
			tlv.isNested = isNested;
			
			if(isNested) {
				tlv.tlvList = getTLVList(value);
			}
			
			tlvList.add(tlv);
		}
		return tlvList;
	}
	
	public static List<TLV> parseWithoutValue(String tlv) {
		try {
			return getTLVListWithoutValue(hexToByteArray(tlv));
		} catch(Exception e) {
			return null;
		}
	}
	
	private static List<TLV> getTLVListWithoutValue(byte[] data) {
		int index = 0;
		
		ArrayList<TLV> tlvList = new ArrayList<TLV>();
		
		while(index < data.length) {
		
			byte[] tag;
			byte[] length;
			
			boolean isNested;
			if((data[index] & (byte)0x20) == (byte)(0x20)) {
				isNested = true;
			} else {
				isNested = false;
			}
			
			if((data[index] & (byte)0x1F) == (byte)(0x1F)) {
				int lastByte = index + 1;
				while((data[lastByte] & (byte)0x80) == (byte)0x80) {
					++lastByte;
				}
				tag = new byte[lastByte - index + 1];
				System.arraycopy(data, index, tag, 0, tag.length);
				index += tag.length;
			} else {
				tag = new byte[1];
				tag[0] = data[index];
				++index;
				
				if(tag[0] == 0x00) {
					break;
				}
			}
			
			if((data[index] & (byte)0x80) == (byte)(0x80)) {
				int n = (data[index] & (byte)0x7F) + 1;
				length = new byte[n];
				System.arraycopy(data, index, length, 0, length.length);
				index += length.length;
			} else {
				length = new byte[1];
				length[0] = data[index];
				++index;
			}
			
			TLV tlv = new TLV();
			tlv.tag = toHexString(tag);
			tlv.length = toHexString(length);
			tlv.isNested = isNested;
			
			tlvList.add(tlv);
		}
		return tlvList;
	}
	
	private static int getLengthInt(byte[] data) {
		if((data[0] & (byte)0x80) == (byte)(0x80)) {
			int n = data[0] & (byte)0x7F;
			int length = 0;
			for(int i = 1; i < n + 1; ++i) {
				length <<= 8; 
				length |= (data[i] & 0xFF);
			}
			return length;
		} else {
			return data[0] & 0xFF;
		}
	}
	
	protected static byte[] hexToByteArray(String s) {
		if(s == null) {
			s = "";
		}
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		for(int i = 0; i < s.length() - 1; i += 2) {
			String data = s.substring(i, i + 2);
			bout.write(Integer.parseInt(data, 16));
		}
		byte[] bytes = bout.toByteArray();
		for (int i = 0; i < bytes.length; i++) {
			TRACE.d("字节数组："+bytes[i]);
		}
		return bytes;
	}
	
	protected static String toHexString(byte[] b) {
		String result = "";
		for (int i=0; i < b.length; i++) {
			result += Integer.toString( ( b[i] & 0xFF ) + 0x100, 16).substring( 1 );
		}
		return result;
	}
	
	public static TLV searchTLV(List<TLV> tlvList, String targetTag) {
		for(int i = 0; i < tlvList.size(); ++i) {
			TLV tlv = tlvList.get(i);
			if(tlv.tag.equalsIgnoreCase(targetTag)) {
				return tlv;
			} else if(tlv.isNested) {
				TLV searchChild = searchTLV(tlv.tlvList, targetTag);
				if(searchChild != null) {
					return searchChild;
				}
			}
		}
		return null;
	}
}
