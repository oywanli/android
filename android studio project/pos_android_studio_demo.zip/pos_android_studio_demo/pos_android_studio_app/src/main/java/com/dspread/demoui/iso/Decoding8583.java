package com.dspread.demoui.iso;



import com.dspread.demoui.iso.Util.ByteUtil;
import com.dspread.demoui.iso.Util.StringUtils;
import com.dspread.demoui.iso.bean.Bean8583;

import java.util.BitSet;


/**
 * <p>
 * Description: 解码8583主类
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Create Date: 2012-09-06
 * </p>
 * <p>
 * Company: HENGBAO
 * </p>
 * 
 * @author husy
 * @version $Id: Decoding85831.java,v 1.1 husy Exp $
 */
public class Decoding8583 {

	/**
	 * 解析银行返回BCD字符串
	 */
	protected String unBcdHex;
	/**
	 * 位图
	 */
	protected BitSet bs;
	/**
	 * 解析BEAN
	 */
	protected Bean8583 bean;
	/**
	 * 字符串索引位置
	 */
	protected int index;
	/**
	 * 字符串临时索引位置
	 */
	protected int tempIndex;
	/**
	 * 是否是128位位图标示
	 */
	protected boolean longBitFlag;
	/**
	 * 有参构造器
	 * 
	 * @param resBytes
	 *            银行返回的压缩BCD字节
	 */
	public Decoding8583(byte[] resBytes) {
		if (null != resBytes && resBytes.length != 0) {
			this.unBcdHex = getResStrUnBCD(resBytes);
			this.bs = getBitSet(resBytes);
			bean = new Bean8583(bs.size());
		}
	}

	/**
	 * 解压银行BCD字节
	 * 
	 * @param resBytes
	 *            银行返回BCD字节
	 * @return 返回解压后的非压缩字符串
	 */
	protected String getResStrUnBCD(byte[] resBytes) {
		//截取长度
//		byte[] block = new byte[resBytes.length-4];
//		System.arraycopy(resBytes, 5, block, 0, block.length);
		// 将压缩BCD字节解压为非压缩字符串
		return ByteUtil.BCDBytesToStr(resBytes);
	}

	/**
	 * 根据银行返回字节获取位图
	 * 
	 * @param bytes
	 *            银行返回字节
	 * @return 位图
	 */
	protected BitSet getBitSet(byte[] resBytes) {
		String bitFornt = unBcdHex.substring(4, 5);
		String bitHexStr="";
		//位图第一位为1表示用了扩展域128个
		if(Integer.valueOf(bitFornt,16)>7){
			// 128位位图,32字节长度获取位图16进制字符串
			bitHexStr = unBcdHex.substring(4, 36);
			longBitFlag = true;
		}else{
			// 64位位图,只有16字节长度
			bitHexStr = unBcdHex.substring(4, 20);
			longBitFlag = false;
		}
		
		// 获取位图2进制字符串
		String binStr = ByteUtil.hexStringToBinStr(bitHexStr);
		// 获取位图
		return ByteUtil.binStringToBitSet(binStr);
	}
	/**
	 * 获取交易码
	 * 
	 * @param tranCode
	 *            交易码
	 */
	protected void getTranCode() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取交易响应码
		bean.setTranCode(unBcdHex.substring(tempIndex, index));
	}

	/**
	 * 解码主函数
	 * 
	 * @return 解析银行后的bean
	 */
	public Bean8583 getResMes() {
		// 解析交易码
		getTranCode();
		// 位图长度
		int len = bs.size();
		// 根据位图调用相应的域的方法
		for (int i = 0; i < len; i++) {
			if ( bs.get(i) || i==0) {
				process(i);
			}
		}
		return bean;
	}

	/**
	 * 解码第一域
	 * 
	 * 返回位图字符串
	 * 
	 * @return 位图字符串		64位或128位	BIN
	 */
	protected String field1() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引	128位位图长度占32字节,64位位图长度占16字节
		if(longBitFlag){
			index = tempIndex + 32;
		}else{
			index = tempIndex + 16;
		}
		// 返回位图字符串
		return unBcdHex.substring(tempIndex, index);

	}

	/**
	 * 解码第二域
	 * 
	 * @return 银行帐号	 LLVAR	n..19	BCD
	 */
	protected String field2() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 2;
		// 获取银行帐号长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取银行帐号补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 索引位置
		tempIndex = index;
		index = tempIndex + fillLen;
		// 根据银行帐号长度获取银行帐号
		String fillBankNo = unBcdHex.substring(tempIndex, index);
		// 获取真正的银行帐号
		return fillBankNo.substring(0, len);
	}

	/**
	 * 解析第三域
	 * 
	 * @return 处理码 	n6	BCD
	 */
	protected String field3() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 6;
		// 返回处理码
		return unBcdHex.substring(tempIndex, index);
	}

	/**
	 * 解析第四域
	 * 
	 * @return 交易额	 n12	BCD
	 */
	protected String field4() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 12;
		// 返回交易额
		return unBcdHex.substring(tempIndex, index);
	}

	/**
	 * 解析第十一域
	 * 
	 * @return 交易流水号	 n6	BCD
	 * 
	 * 注释:广东转账接口为n20
	 */
	protected String field11() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 6;
		// 返回交易额
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第十二域
	 * 
	 * @return 交易时间	 n6	BCD
	 * 
	 */
	protected String field12() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 6;
		// 返回交易额
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第十二域
	 * 
	 * @return 交易日期	 n4	BCD
	 * 
	 */
	protected String field13() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 返回交易额
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第十四域
	 * 
	 * @return	卡有效期	n4	BCD
	 */
	protected String field14(){
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 返回交易额
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第十五域
	 * 
	 * @return 	结帐日/清算日期	n4	BCD
	 */
	protected String field15() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 返回清算日期
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第二十二域
	 * 
	 * @return	服务点输入方式码	n3	BCD
	 */
	protected String field22(){
		// 设置临时索引
		tempIndex = index;
		// 设置位置索引
		index = tempIndex+3;
		//返回服务点输入方式
		return unBcdHex.substring(tempIndex, index++);
	}
	
	/**
	 * 解析第二十三域
	 * 
	 * @return	卡片序列号	n3	BCD
	 */
	protected String field23(){
		// 设置临时索引
		tempIndex = index;
		// 设置位置索引
		index = tempIndex+3;
		//返回卡序列号
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第二十五域
	 * 
	 * @return	服务点条件码	n2	BCD
	 */
	protected String field25(){
		// 设置临时索引
		tempIndex = index;
		// 设置位置索引
		index = tempIndex + 2;
		//返回服务点条件码
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 解析第二十六域
	 * 
	 * @return	服务点PIN获取码	n2	BCD
	 */
	protected String field26(){
		// 设置临时索引
		tempIndex = index;
		// 设置位置索引
		index = tempIndex + 2;
		// 返回服务点PIN获取码
		return unBcdHex.substring(tempIndex, index);
	}

	/**
	 * 解析第三十二域
	 * 
	 * @return 代理方机构标识代码	LLVAR	n..11	BCD
	 */
	protected String field32() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 2;
		// 获取代理方机构标识代码长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取代理方机构标识代码补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 索引位置
		tempIndex = index;
		index = tempIndex + fillLen;
		// 根据代理方机构标识代码长度获取代理方机构标志码
		String fillProxyOrganNo = unBcdHex.substring(tempIndex, index);
		// 获取真正的代理方机构标识代码
		return fillProxyOrganNo.substring(0, len);
	}
	
	/**
	 * 解析第三十五域
	 * 
	 * @return	2磁道数据	LLVAR	z..37	BCD
	 */
	protected String field35(){
		// 设置临时索引
		tempIndex = index;
		// 设置长度索引位置
		index = tempIndex + 2;
		//	获取2磁道数据内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取2磁道数据补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据2磁道数据长度获取代理2磁道数据
		String fillSecondTrank = unBcdHex.substring(tempIndex, index);
		// 获取真正的2磁道数据
		return fillSecondTrank.substring(0, len);
	}
	
	/**
	 * 解析第三十六域
	 * 
	 * @return	3磁道数据	LLLVAR	z...114	BCD
	 */
	protected String field36(){
		// 设置临时索引
		tempIndex = index;
		// 设置长度索引位置
		index = tempIndex + 4;
		//	获取3磁道数据内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取3磁道数据补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据3磁道数据长度获取代理3磁道数据
		String fillThirdTrank = unBcdHex.substring(tempIndex, index);
		// 获取真正的3磁道数据
		return fillThirdTrank.substring(0, len);
	}
		
	/**
	 * 解析第三十七域
	 * 
	 * @return 系统参考号		an12	ASCII
	 */
	protected String field37() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 24;
		// 获取本地编码字符串16进制
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回系统参考号
		return ByteUtil.hexStringToStrLocal(localHexStr);
	}
	
	/**
	 * 解析第三十八域
	 * 
	 * @return	授权标识应答码	an6	ASCII
	 */
	protected String field38(){
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 12;
		// 获取本地编码字符串16进制
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回授权标识应答码
		return ByteUtil.hexStringToStrLocal(localHexStr);
	}
	

	/**
	 * 解析第三十九域
	 * 
	 * @return 响应码	an2	ASCII
	 */
	protected String field39() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取本地编码字符串16进制
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回响应码
		return ByteUtil.hexStringToStrLocal(localHexStr);
	}

	/**
	 * 解析第四十一域
	 * 
	 * @return 终 端 机 号		ans8	ASCII
	 */
	protected String field41() {
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 16;
		// 获取本地编码字符串16进制
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回响应码
		return ByteUtil.hexStringToStrLocal(localHexStr);
	}
	
	/**
	 * 解析第四十二域
	 * 
	 * @return	 商户号	ans15	ASCII
	 */
	protected String field42(){
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 30;
		// 获取商户号本地编码字符串16进制
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回商户号
		return ByteUtil.hexStringToStrLocal(localHexStr);
	}

	/**
	 * 解析第四十四域
	 * 
	 * @return	 商户号	ans15	ASCII
	 */
	protected String field44() {
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 2;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		
		int fillLen = len * 2;
		// 索引位置
		tempIndex = index;
		// 结束位置
		index = tempIndex + fillLen;
		// 根据银行帐号长度获取银行帐号
		String operCode = unBcdHex.substring(tempIndex, index);
		// 返回数据
		operCode = ByteUtil.hexStringToStrLocal(operCode);
		// 返回域值
		return operCode.substring(0,len);
	}
	/**
	 * 解析第四十八域
	 * 
	 * @return 附 加 数 据		LLLVAR	BCD
	 */
	protected String field48() {// 设置临时索引
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取3磁道数据补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回响应码
		return localHexStr.substring(0,len);
	}

	/**
	 * 解析四十九域
	 * 
	 * @return	交易货币代码		an3 	ASCII
	 */
	protected String field49(){
		// 设置临时索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 6;
		// 获取交易货币代码本地编码字符串16进制
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回交易货币代码
		return ByteUtil.hexStringToStrLocal(localHexStr);
	}
	
	/**
	 * 解析第五十二域
	 * 
	 * @return	个人标识码数据	b64	 BIN
	 */
	protected String field52(){
		// 设置临时索引
		tempIndex = index;
		// 设置位置索引
		index = tempIndex + 16;
		// 返回个人标识码
		String str = unBcdHex.substring(tempIndex, index);
		// 个人标识码数据
		return str;
	}
	
	/**
	 * 解析第五十三域
	 * 
	 * @return	安全控制信息	n16	BCD
	 */
	protected String field53(){
		// 设置临时索引
		tempIndex = index;
		// 设置位置索引
		index = tempIndex + 16;
		// 返回个人标识码
		return unBcdHex.substring(tempIndex, index);
	}
	/**
	 * 解析第五十四域
	 * 
	 * @return	
	 */
	protected String field54() {
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取数据补齐后长度
		int fillLen = len *2;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据54域数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		localHexStr=ByteUtil.hexStringToStrLocal(localHexStr);
		// 返回54域
		return localHexStr.substring(0,len);
	}
	/**
	 * 解析第五十五域
	 * 
	 * @return	IC卡数据域	LLLVAR	
	 */
	protected String field55(){
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取3磁道数据补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回响应码
		return localHexStr.substring(0,len);
	}
	
	/**
	 * 解析第五十九域
	 * 
	 * @return	自定义域		LLLVAR	ANS	ASCII
	 */
	protected String field59(){
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		//System.out.println("len====="+len);
		// 获取数据补齐后长度
		int fillLen = len * 2;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		//System.out.println("tempIndex="+tempIndex+"   index="+index);
		//System.out.println("==================================");
		// 根据59域数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回59域
		String localStr = StringUtils.decode(localHexStr,"GBK");
		return localStr.substring(0,len);
	}
	
	/**
	 * 解析第六十域
	 * @return	自定义域		n...011	LLLVAR	BCD
	 */
	protected String field60(){
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取60域数据补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回60域
		return localHexStr.substring(0,len);
	}
	
	/**
	 * 解析六十一域
	 * 
	 * @return	原始数据 n...029	LLLVAR	BCD
	 */
	protected String field61(){
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取61域数据补齐后长度
		int fillLen = len % 2 == 0 ? len : len + 1;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据61域数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回61域
		return localHexStr.substring(0,len);
	}
	
	/**
	 * 解析第六十二域
	 * 
	 * @return	自定义域		LLLVAR	ans...512	ASCII
	 */
	protected String field62(){
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		// 获取数据补齐后长度
		int fillLen = len *2;
		// 数据临时索引位置
		tempIndex = index;
		// 数据索引位置
		index = tempIndex + fillLen;
		// 根据62域数据长度获取数据
		String localHexStr = unBcdHex.substring(tempIndex, index);
		// 返回62域
		return localHexStr.substring(0,fillLen);
	}
	
	/**
	 * 解析第六十三域
	 * 
	 * @return	自定义域	 LLLVAR  ans...63	ASCII
	 */
	protected String field63(){
		// 设置长度位置索引
		tempIndex = index;
		// 设置索引
		index = tempIndex + 4;
		// 获取内容长度
		int len = Integer.valueOf(unBcdHex.substring(tempIndex, index));
		
		int fillLen = len * 2;
		// 索引位置
		tempIndex = index;
		// 结束位置
		index = tempIndex + fillLen;
		// 根据银行帐号长度获取银行帐号
		String operCode = unBcdHex.substring(tempIndex, index);
		// 返回63域数据
		operCode = ByteUtil.hexStringToStrLocal(operCode);
		// 返回实际的63域值
		return operCode.substring(0,len);
	}
	
	/**
	 * 解析第六十四域
	 * 
	 * @return	MAC	b64	BIN
	 */
	protected String field64(){
		// 设置临时索引位置
		tempIndex = index;
		//	设置位置索引
		index = tempIndex + 16;
		// 返回MAC
		return unBcdHex.substring(tempIndex, index);
	}
	
	/**
	 * 根据传入的值选择执行解析域的方法
	 * 
	 * @param pro
	 *            域(位图从0至(length -1))
	 */
	protected void process(int pro) {
		// 发送到广东省中山市建行自助圈存交易流程
		switch (pro) {
		case 0:
			bean.setField1(field1());
			break;
		case 1:
			bean.setField2(field2());
			break;
		case 2:
			bean.setField3(field3());
			break;
		case 3:
			bean.setField4(field4());
			break;
		case 10:
			bean.setField11(field11());
			break;
		case 14:
			bean.setField15(field15());
			break;
		case 31:
			bean.setField32(field32());
			break;
		case 36:
			bean.setField37(field37());
			break;
		case 38:
			bean.setField39(field39());
			break;
		case 40:
			bean.setField41(field41());
			break;
		case 47:
			bean.setField48(field48());
			break;
		default:
			break;
		}
	}

}
