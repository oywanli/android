package com.dspread.demoui.utils;

public interface Field {
	/* convert field content to bytes with BCD or ASCII encoding */
	public byte[] toBytes();
	/* initialize Field content with bytes in #data beginning with #offset
	 * return the number of bytes consumed in initialization, or negative value if failed. */
	public int init(byte[] data, int offset);
	/* return the number of field */
	public int getType();
}
