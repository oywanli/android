package com.dspread.demoui.iso;




import com.dspread.demoui.iso.Util.ByteUtil;
import com.dspread.demoui.iso.Util.StringUtils;
import com.dspread.demoui.iso.bean.Bean8583;

import java.util.BitSet;


/**
 * <p>
 * Description: 8583编码主类(打包)
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Create Date: 2012-09-06
 * </p>
 * <p>
 * Company: HENGBAO
 * </p>
 * 
 * @author husy
 * @version $Id: Encoding8583.java,v 1.1 husy Exp $
 */
public class Encoding8583 {
	/**
	 * 数据域封装BEAN
	 */
	protected Bean8583 bean = null;

	/**
	 * 有参构造器
	 */
	public Encoding8583(Bean8583 bean) {
		this.bean = bean;
	}

	/**
	 * 编码主函数
	 * 
	 * @param bean
	 *            传输到银行的数据的封装
	 * @return 即将发送到银行的数据串
	 */
	public String getReqMes() {
		// 交易码的16进制字符串
		String tranCodeBCD = getTranCode(bean.getTranCode());
		// 发送到银行的字符串
		StringBuilder builder = new StringBuilder(tranCodeBCD);
		// 位图
		BitSet bs = bean.getBs();
		// 位图长度
		int len = bs.size();
		// 根据位图调用相应的域的方法
		for (int i = 0; i < len; i++) {
			if (bs.get(i) || i==0) {			//64位位图位图标志位就是0
				builder.append(process(i));
			}
		}
		return builder.toString();
	}

	/**
	 * 获取交易码的BCD压缩字节数组并转换为16进制字符串
	 * 
	 * @param tranCode
	 *            交易码
	 * @return 16进制数组
	 */
	protected String getTranCode(String tranCode) {
		// 获取交易码的BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(tranCode);
		// 将压缩字节转换为16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}

	/**
	 * 第一域(64位图表示第一域)否则为第一域与高64位的混合
	 * 
	 * 根据位图对象获取位图的字符串 表现形式
	 * 
	 * @param bs
	 *            位图
	 * @return 位图的字符串形式0与1的组合
	 */
	protected String field1(BitSet bs) {
		// 将字符串位图转化为字符串
		String binStr = ByteUtil.bitSetToBinString(bs);
		// 将字符串转化成16进制字符串 111100111100 --> 1111 0011 1100 --> F3C
		String hexStr = ByteUtil.binStrToHexString(binStr);
		// 获取位图字符串的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(hexStr);
		// 获取字节16进制的字符串
		String bitHex = ByteUtil.bytesToHexString(bytes);
		// 返回字符串
		return bitHex;
	}

	/**
	 * 打包第二域(银行帐号)
	 * 
	 * 2位变长+最大19字节内容
	 * 
	 * @param field1
	 *            第二域字段
	 * @return 返回第二域编码之后的字符串	LLVAR
	 */
	protected String field2(String field2) {
		int len = field2.length();
		// 不足两位补0压缩
		String realLen = StringUtils.fillZeroLeft(len, 2);
		// 获取长度的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(realLen);
		// 获取字节对应的16进制字符串
		String lenStr = ByteUtil.bytesToHexString(bytes);
		// 判断银行帐号是否可压缩BCD
		len = len % 2 == 0 ? len : len + 1;
		// 将银行帐号左补0,使其可压缩BCD
		field2 = StringUtils.fillZeroRight(field2, len);
		// 获取银行帐号的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(field2);
		// 获取字节对应的16进制字符串
		String bankNoStr = ByteUtil.bytesToHexString(byts);
		// 返回长度(BCD)+银行帐号(BCD)
		return lenStr + bankNoStr;
	}

	/**
	 * 打包第三域(交易处理码)
	 * 
	 * 6字节定长
	 * 
	 * @param field3
	 *            交易处理码
	 * @return 交易处理码的BCD字符串
	 */
	protected String field3(String field3) {
		// 获取交易处理码的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field3);
		// 获取交易处理码的16进制
		String tranProCodeStr = ByteUtil.bytesToHexString(bytes);
		// 返回交易处理码
		return tranProCodeStr;
	}

	/**
	 * 打包第四域(交易金额)
	 * 
	 * 12字节定长,右靠左补0
	 * 
	 * @param field4
	 *            交易金额
	 * @return 交易金额的BCD字符串
	 */
	protected String field4(String field4) {
		// 左补0,补齐12位
		field4 = StringUtils.fillZeroLeft(field4, 12);
		// 获取交易金额的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field4);
		// 获取交易金额的16进制字符串
		String tranAmtStr = ByteUtil.bytesToHexString(bytes);
		// 返回交易金额的16进制字符串
		return tranAmtStr;
	}

	/**
	 * 打包第七域(传送日期时间)
	 * 
	 * 10字节定长 MMddHHmmss
	 * 
	 * @param field7
	 *            交易传送日期
	 * @return 交易传送日期的16进制字符串
	 */
	protected String field7(String field7) {
		// 获取传送日期时间压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field7);
		// 获取字节的16进制字符串
		String sendDate = ByteUtil.bytesToHexString(bytes);
		// 返回传送日期时间的16进制字符串
		return sendDate;

	}

	/**
	 * 打包第十一域(受卡方系统跟踪号)
	 * 
	 * 6字节定长(一卡通平台唯一流水号)
	 * 
	 * @param field11
	 *            POS交易流水号
	 * @return 交易流水号的16进制字符串
	 */
	protected String field11(String field11) {
		// 获取受卡方系统跟踪号压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field11);
		// 获取字节的16进制字符串
		String tranNo = ByteUtil.bytesToHexString(bytes);
		// 返回POS流水号的16进制字符串
		return tranNo;
	}

	/**
	 * 打包第十二域(受卡方所在地时间)
	 * 
	 * 6字节定长(交易时间)
	 * 
	 * @param field12
	 *            交易时间
	 * @return 交易时间的16进制字符串
	 */
	protected String field12(String field12) {
		// 获取受卡方所在地时间压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field12);
		// 获取字节的16进制字符串
		String tranTime = ByteUtil.bytesToHexString(bytes);
		// 返回交易时间的16进制字符串
		return tranTime;
	}

	/**
	 * 打包第十三域(受卡方所在地日期)
	 * 
	 * 4字节定长(交易日期)	MMDD
	 * 
	 * @param field13
	 *            交易日期
	 * @return 交易日期的16进制字符串
	 */
	protected String field13(String field13) {
		// 获取受卡方所在地日期压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field13);
		// 获取字节的16进制字符串
		String tranDate = ByteUtil.bytesToHexString(bytes);
		// 返回交易日期的16进制字符串
		return tranDate;
	}

	/**
	 * 打包第十四域(卡有效期)
	 * 
	 * 4字节定长
	 * 
	 * @param field14	BCD
	 * 				卡有效期
	 * @return	卡有效期的16进制字符串
	 */
	protected String field14(String field14){
		// 获取卡有效期压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field14);
		// 获取字节的16进制字符串
		String validDate = ByteUtil.bytesToHexString(bytes);
		// 返回卡有效期的16进制字符串
		return validDate;
	}
	/**
	 * 打包第十五域(清算日期)
	 * 
	 * 4字节定长(清算日期)
	 * 
	 * @param field15	n4	BCD
	 *            清算日期
	 * @return 结帐/清算日期的16进制字符串
	 */
	protected String field15(String field15) {
		// 获取清算日期压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field15);
		// 获取字节的16进制字符串
		String clearDate = ByteUtil.bytesToHexString(bytes);
		// 返回结帐日期的16进制字符串
		return clearDate;
	}
	/**
	 * 打包第二十二域(服务点输入方式码)
	 * 
	 * 3字节定长
	 * 
	 * @param field22	n3	BCD
	 *            服务点输入方式码
	 * @return 服务点输入方式码的16进制字符串
	 */
	protected String field22(String field22) {
		byte[] bytes = ByteUtil.strToBCDBytes(field22);
		return ByteUtil.bytesToHexString(bytes);
	}
	
	/**
	 * 打包第二十三域
	 * 
	 * 3字节定长(卡片序列号)
	 * 
	 * @param field23	n3	BCD
	 * 				卡片序列号
	 * @return	卡片序列号的16进制字符串
	 */
	protected String field23(String field23){
		// 获取卡片序列号压缩BCD码
		byte[] bytes = ByteUtil.strToBCDBytes(field23);
		// 返回卡片序列号的16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}
	
	/**
	 * 打包第二十五域
	 * 
	 * 2字节定长(服务点条件代码)
	 * 
	 * @param field25	n2	BCD
	 * 				服务点条件代码
	 * @return	服务点条件代码的16进制字符串
	 */
	protected String field25(String field25){
		// 获取服务点条件代码
		byte[] bytes = ByteUtil.strToBCDBytes(field25);
		// 返回服务点条件代码的16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}
	/**
	 * 打包第二十六域
	 * 
	 * 2字节定长(服务点PIN获取码)
	 * 
	 * @param field26	n2	BCD
	 * 				服务点PIN获取码
	 * @return	服务点PIN获取码的16进制字符串
	 */

	protected String field26(String field26) {
		byte[] bytes = ByteUtil.strToBCDBytes(field26);
		return ByteUtil.bytesToHexString(bytes);
	}
	/**
	 * 打包第二十八域(交易手续费)
	 * 
	 * 9字节定长数字+字符
	 * 
	 * @param field28
	 *            交易手续费
	 * @return 交易手续费-->16进制字符串-->压缩BCD字节-->16进制字符串
	 */
	protected String field28(String field28) {
		// 获取交易手续费的16进制字符串
		String hexStr = ByteUtil.strLocalToHexString(field28);
		// 获取压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(hexStr);
		// 获取压缩BCD字节对应的16进制字符串
		String handleFee = ByteUtil.bytesToHexString(bytes);
		// 返回手续费的16进制字符串
		return handleFee;
	}

	/**
	 * 打包第三十二域(代理方机构标识代码)
	 * 
	 * 2位变长最大长度11 2字节长度+11字节变长
	 * 
	 * @param field32	LLVAR	BCD
	 *            代理方机构标识代码
	 * @return 1字节长度+3字节标识代码 的16进制字符串
	 */
	protected String field32(String field32) {
		int len = field32.length();
		// 获取长度不足两位左补0
		String realLen = StringUtils.fillZeroLeft(len, 2);
		// 获取长度的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(realLen);
		// 获取长度压缩BCD字节对应的16进制字符串
		String lenStr = ByteUtil.bytesToHexString(bytes);
		// 机构标示代码是否可压缩
		len = len % 2 == 0 ? len : len + 1;
		// 左补0，使其可压缩BCD
		field32 = StringUtils.fillZeroRight(field32, len);
		// 获取学校代码的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(field32);
		// 获取学校代码压缩BCD字节对应的16进制字符串
		String strOrganHex = ByteUtil.bytesToHexString(byts);
		// 返回长度+学校代码16进制字符串
		return lenStr + strOrganHex;
	}
	/**
	 * 打包第三十五域(二磁道信息)
	 * 
	 * 2位变长最大长度37 2字节长度+37字节变长
	 * 
	 * @param field35	LLVAR	BCD
	 *            二磁道加密信息
	 * @return 1字节长度+3字节标识代码 的16进制字符串
	 */
	protected String field35(String field35) {
		int len = field35.length();
		// 获取长度不足两位左补0
		String realLen = StringUtils.fillZeroLeft(len, 2);
		// 获取长度的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(realLen);
		// 获取长度压缩BCD字节对应的16进制字符串
		String lenStr = ByteUtil.bytesToHexString(bytes);
		// 二磁道加密信息是否可压缩
		len = len % 2 == 0 ? len : len + 1;
		// 左补0，使其可压缩BCD
		field35 = StringUtils.fillZeroRight(field35, len);
		// 获取二磁道加密信息的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(field35);
		// 获取二磁道加密信息压缩BCD字节对应的16进制字符串
		String strOrganHex = ByteUtil.bytesToHexString(byts);
		// 返回长度+二磁道加密信息16进制字符串
		return lenStr + strOrganHex;
	}
	/**
	 * 打包第三十六域(三磁道信息)
	 * 
	 * 4位变长最大长度104 4字节长度+104字节变长
	 * 
	 * @param field36	LLLVAR	BCD
	 *            代理方机构标识代码
	 * @return 2字节长度+104字节标识代码 的16进制字符串
	 */
	protected String field36(String field36) {
		int len = field36.length();
		// 获取长度不足两位左补0
		String realLen = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(realLen);
		// 获取长度压缩BCD字节对应的16进制字符串
		String lenStr = ByteUtil.bytesToHexString(bytes);
		// 二磁道加密信息是否可压缩
		len = len % 2 == 0 ? len : len + 1;
		// 左补0，使其可压缩BCD
		field36 = StringUtils.fillZeroRight(field36, len);
		// 获取二磁道加密信息的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(field36);
		// 获取二磁道加密信息压缩BCD字节对应的16进制字符串
		String strOrganHex = ByteUtil.bytesToHexString(byts);
		// 返回长度+二磁道加密信息16进制字符串
		return lenStr + strOrganHex;
	}
	/**
	 * 打包三十七域(检索参考号)
	 * 
	 * 12字节定长
	 * 
	 * @param field37	an12	ASCII
	 *            系统参考号
	 * @return 返回系统参考号的16进制字符串
	 */
	protected String field37(String field37) {
		// 左补0,补齐12位
		field37 = StringUtils.fillZeroLeft(field37, 12);
		// 获取系统参考号的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field37);
		// 获取系统参考号的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 获取系统参考号压缩BCD字节对应的16进制字符串
		String strSysTranCode = ByteUtil.bytesToHexString(bytes);
		// 返回系统参考号压缩BCD字节的16进制字符串
		return strSysTranCode;
	}
	
	/**
	 * 打包第三十八域(授权码)
	 * 
	 * @param field38	an6	ASCII
	 * 				授权码
	 * @return	返回授权码的16进制字符串
	 */
	protected String field38(String field38){
		// 左补0,补齐6位
		field38 = StringUtils.fillZeroLeft(field38, 6);
		// 获取授权码的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field38);
		// 获取授权码压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 返回授权码16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}

	/**
	 * 打包第三十九域(响应码)
	 * 
	 * @param field39	an2	ASCII
	 * 				响应码
	 * @return	返回响应码的16进制字符串
	 */
	protected String field39(String field39){
		// 左补0,补齐2位
		field39 = StringUtils.fillZeroLeft(field39, 2);
		// 获取响应码的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field39);
		// 获取响应码的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 返回响应码16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}
	
	/**
	 * 打包第四十一域(终端机号)
	 * 
	 * 8字节定长
	 * 
	 * @param field41	ans8	ASCII
	 *            终端机号
	 * @return 返回终端机号的16进制字符串
	 */
	protected String field41(String field41) {
		// 左补0,补齐8位
		field41 = StringUtils.fillZeroLeft(field41, 8);
		// 获取终端号的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field41);
		// 获取终端机号的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 获取终端机号压缩BCD字节对应的16进制字符串
		String termCode = ByteUtil.bytesToHexString(bytes);
		// 返回终端机号压缩BCD字节的16进制字符串
		return termCode;
	}

	/**
	 * 打包第四十二域(商户号)
	 * 
	 * 15字节定长
	 * 
	 * @param field42	ans15	ASCII
	 * 				商户号
	 * @return	返回商户号的16进制字符串
	 */
	protected String field42(String field42){
		// 左补0,补齐15位
		field42 = StringUtils.fillZeroLeft(field42, 15);
		// 获取商户号的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field42);
		// 获取商户号的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 返回商户号压缩BCD字节对应的16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}
	
	/**
	 * 打包四十四域(附加响应数据)
	 * 
	 * @param field44	LLVAR	ans..25	 ASCII
	 * 
	 * @return	附加响应数据的16进制字符串
	 */
	protected String field44(String field44){
		// 获取打包44域的长度
		int len = field44.length();
		// 获取长度不足两位左补0
		String strlen = StringUtils.fillZeroLeft(len,2);
		// 获取长度的BCD字节
		byte[] lenbyte = ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		String Hexlen = ByteUtil.bytesToHexString(lenbyte);
		// 长度转为BCD
		len = len % 2 == 0?len:len+1;
		// 获取附加响应数据的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field44);
		// 获取附加响应数据的BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 获取附加响应数据的16进制字符串
		strHex = ByteUtil.bytesToHexString(bytes);
		// 返回变长格式的附加响应数据
		return Hexlen + strHex;
	}
	
	/**
	 * 打包第四十八域(附加数据私有数据)
	 * 
	 * 62字节 (18位银行流水号+44空格) 经日志分析应该是18位身份证号+44空格
	 * 
	 * @param field48	LLLVAR	ans...062	BCD
	 *            私有数据
	 * @return 返回私有数据的16进制字符串
	 */
	protected String field48(String field48) {
		// 获取48域的长度
		int len = field48.length();
		// 长度不足3位左补0
		String lenstr = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的压缩BCD字节
		byte[] byt = ByteUtil.strToBCDBytes(lenstr);
		// 获取长度的16进制字符串
		String hexLen = ByteUtil.bytesToHexString(byt);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len:len+1;
		// 补齐62字节不足右补空格
		field48 = StringUtils.fillZeroRight(field48, len);
		// 获取附加数据私有数据的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field48);
		// 获取附加数据私有数据压缩BCD字节对应的16进制字符串
		String privateData = ByteUtil.bytesToHexString(bytes);
		// 返回附加数据私有数据压缩BCD字节的16进制字符串
		return hexLen + privateData;
	}
	
	/**
	 * 打包四十九域(交易货币代码)
	 * 
	 * @param field49	an3	 ASCII
	 * 				交易货币代码
	 * @return	返回交易货币代码的16进制字符串
	 */
	protected String field49(String field49){
		// 左补0,补齐3位
		field49 = StringUtils.fillZeroLeft(field49, 3);
		// 获取交易货币代码的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field49);
		// 获取交易货币代码的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 获取交易货币代码压缩BCD字节的16进制字符串
		String moneyCode = ByteUtil.bytesToHexString(bytes);
		// 返回交易货币代码压缩BCD字节的16进制字符串
		return moneyCode;
	}

	/**
	 * 打包第五十二域(个人标识码数据)
	 * 
	 * 8字节定长
	 * 
	 * @param field52	b64	BIN
	 *            个人标识码数据
	 * @return 返回个人标识码数据的16进制字符串
	 */
	protected String field52(String field52) {
		// 获取个人标识码数据的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field52);
		// 获取个人标识码数据压缩BCD字节对应的16进制字符串
		String password = ByteUtil.bytesToHexString(bytes);
		// 返回个人标识码数据压缩BCD字节的16进制字符串
		return password;
	}
	
	/**
	 * 打包第五十三域(安全控制信息)
	 * 
	 * @param field53	n16	 BCD
	 * 
	 * @return	返回安全控制信息
	 */
	protected String field53(String field53){
		// 左补0,补齐16位
		field53 = StringUtils.fillZeroLeft(field53, 16);
		// 获取安全控制信息
		byte[] bytes = ByteUtil.strToBCDBytes(field53);
		// 返回安全控制信息的16进制字符串
		return ByteUtil.bytesToHexString(bytes);
	}
	
	/**
	 * 打包第五十四域(附加金额)
	 * 
	 * @param field54	LLLVAR	an...020	ASCII
	 * 
	 * @return	附加金额
	 */
	protected String field54(String field54){
		int len = field54.length();
		// 获取长度不足3位左补零
		String strlen = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的BCD字节
		byte[] blen = ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		String hexLen = ByteUtil.bytesToHexString(blen);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
		field54 = StringUtils.fillZeroRight(field54, len);
		// 获取附加金额的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field54);
		// 获取附加金额的BCD字节
		byte[] bytes = ByteUtil.hexStringToBytes(strHex);
		// 获取附加金额的16进制字符串
		strHex = ByteUtil.bytesToHexString(bytes);
		// 返回附加金额的16进制字符串
		return hexLen + strHex;
	}
	
	/**
	 * 打包第五十五域(IC卡数据域)
	 * 
	 * @param field55	LLLVAR	最大255字节
	 * 
	 * @return	IC卡数据域
	 */
	protected String field55(String field55){
		int len = field55.length();
		// 获取长度不足3位左补0
		String strlen = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的BCD字节
		byte[] blen = ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		String hexLen = ByteUtil.bytesToHexString(blen);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
		field55 = StringUtils.fillZeroRight(field55, len);
//		// 获取IC卡数据域的16进制字符串
//		String strHex = ByteUtil.strLocalToHexString(field55);
//		// 获取IC卡数据域的BCD字节
//		byte[] bytes = ByteUtil.hexStringToBytes(strHex);
//		// 获取IC卡数据域的16进制字符串
//		strHex = ByteUtil.bytesToHexString(bytes);
		// 返回IC卡数据域
		return hexLen + field55;
	}
	
	/**
	 * 打包第五十九域(自定义域)
	 * 
	 * @param field59	LLLVAR	 ASCII
	 * 				自定义域
	 * @return	自定义域
	 */
	protected String field59(String field59){
		int len = field59.length();
		// 获取长度不足3位左补0
		String strlen = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的BCD字节
		byte[] blen =  ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		String hexLen = ByteUtil.bytesToHexString(blen);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
//		field59 = StringUtil.fillZeroRight(field59, len);
		// 获取自定义域的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field59);
		// 获取自定义域的BCD字节
//		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 获取自定义域的16进制字符串
//		strHex = ByteUtil.bytesToHexString(bytes);
		len = strHex.length()/2;	//字符长度
		strlen = StringUtils.fillZeroLeft(len, 4);
		hexLen = ByteUtil.bytesToHexString(ByteUtil.strToBCDBytes(strlen));
		// 返回自定义域
		return hexLen + strHex;
	}
	
	/**
	 * 打包第六十域(自定义域)
	 * 
	 * @param field60	LLLVAR	n...011 BCD
	 * 				自定义域
	 * @return	自定义域
	 */
	protected String field60(String field60){
		int len = field60.length();
		// 获取长度不足3位左补0
		String strlen = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的BCD字节
		byte[] blen =  ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		String hexLen = ByteUtil.bytesToHexString(blen);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
		field60 = StringUtils.fillZeroRight(field60, len);
		// 获取自定义域的BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field60);
		// 获取自定义域的16进制字符串
		String strHex = ByteUtil.bytesToHexString(bytes);
		// 返回自定义域
		return hexLen + strHex;
	}
	/**
	 * 打包第六十一域(自定义域)
	 * @param field61
	 * @return
	 */
	protected String field61(String field61) {
		int len = field61.length();
		// 获取长度不足3位左补0
		String strlen = StringUtils.fillZeroLeft(len, 4);
		// 获取长度的BCD字节
		byte[] blen =  ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		String hexLen = ByteUtil.bytesToHexString(blen);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
		field61 = StringUtils.fillZeroRight(field61, len);
		// 获取自定义域的BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field61);
		// 获取自定义域的16进制字符串
		String strHex = ByteUtil.bytesToHexString(bytes);
		// 返回自定义域
		return hexLen + strHex;
	}

	/**
	 * 打包第六十二域(自定义域)
	 * 
	 * @param field62	LLLVAR	ans...22	BCD
	 * 
	 * @return	自定义域	终端工作密钥
	 */
	protected String field62(String field62){
		int len = field62.length();
		// 获取长度不足3位左补0
		String strlen = StringUtils.fillZeroLeft(len, 4);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
		field62 = StringUtils.fillZeroRight(field62, len);
		// 获取自定义域的16进制字符串
//		String strHex = ByteUtil.strLocalToHexString(field62);
		// 获取自定义域的BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(field62);
		// 获取自定义域的16进制字符串
		String strHex = ByteUtil.bytesToHexString(bytes);
		strlen = StringUtils.fillZeroLeft(strHex.length()/2, 4);
		String realLen = ByteUtil.bytesToHexString(ByteUtil.strToBCDBytes(strlen));
		// 返回自定义域
		return realLen + strHex;
	}
	
	/**
	 * 打包第六十三域(自定义域)
	 * 
	 * @param field63	LLLVAR	ans...063	ASCII
	 * 
	 * @return
	 */
	protected String field63(String field63) {
		int len = field63.length();
		// 获取长度不足3位左补0
		String strlen = StringUtils.fillZeroLeft(field63.length(), 4);
		// 获取长度的BCD字节
		//byte[] blen = ByteUtil.strToBCDBytes(strlen);
		// 获取长度的16进制字符串
		// String hexLen = ByteUtil.bytesToHexString(blen);
		// 判断长度是否需要补位
		// len = len % 2 ==0 ? len :len+1;
		// 根据长度补位
		// field63 = StringUtils.fillZeroRight(field63, len);
		// 获取自定义域的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field63);
		len = strHex.length() / 2; // 字符长度
		strlen = StringUtils.fillZeroLeft(len, 4);
		String hexLen = ByteUtil.bytesToHexString(ByteUtil.strToBCDBytes(strlen));
		// 返回自定义域
		return hexLen + strHex;
	}
	
	/**
	 * 打包第六十四域(MAC)
	 * 
	 * @param field64	b64	BIN
	 * 
	 * @return	MAC
	 */
	protected String field64(String field64){
		// 获取MAC的16进制字符串
//		String hex = ByteUtil.strLocalToHexString(field64);
		// 获取MAC的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(field64);
		// 获取MAC压缩BCD字节对应的16进制字符串
		String macHex = ByteUtil.bytesToHexString(byts);
		// 返回交易说明的16进制字符串
		return macHex;
	}
	
	/**
	 * 打包第一百域(接收机构标识代码)
	 * 
	 * 6字节定长
	 * 
	 * @param field100
	 *            接收机构标识代码
	 * @return 返回 接收机构标识代码16进制字符串
	 */
	protected String field100(String field100) {
		// 获取接收机构标识代码的16进制字符串
		String strHex = ByteUtil.strLocalToHexString(field100);
		// 获取接收机构标识代码的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strHex);
		// 获取接收机构标识代码压缩BCD字节对应的16进制字符串
		String recOrganCode = ByteUtil.bytesToHexString(bytes);
		// 返回接收机构标识代码压缩BCD字节的16进制字符串
		return recOrganCode;
	}

	/**
	 * 打包第一百零四域(交易说明)
	 * 
	 * 域定义3位变长 目前仅为P或T
	 * 
	 * @param field104
	 *            交易说明
	 * @return 返回交易说明的16进制字符串
	 */
	protected String field104(String field104) {
		int len = field104.length();
		// 获取长度不足两位左补0
		String strLen = StringUtils.fillZeroLeft(len, 2);
		// 获取长度的压缩BCD字节
		byte[] bytes = ByteUtil.strToBCDBytes(strLen);
		// 获取长度压缩BCD字节对应的16进制字符串
		String strHex = ByteUtil.bytesToHexString(bytes);
		// 判断长度是否需要补位
		len = len % 2 ==0 ? len :len+1;
		//根据长度补位
		field104 = StringUtils.fillZeroRight(field104, len);
		// 获取交易说明的16进制字符串
		String hex = ByteUtil.strLocalToHexString(field104);
		// 获取交易说明的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(hex);
		// 获取交易说明压缩BCD字节对应的16进制字符串
		String tranDesc = ByteUtil.bytesToHexString(byts);
		// 返回交易说明的16进制字符串
		return strHex + tranDesc;
	}

	/**
	 * 打包第128域(MAC)
	 * 
	 * 64BIT=8字节定长
	 * 
	 * @param field128
	 *            MAC
	 * @return 返回MAC的16进制字符串
	 */
	protected String field128(String field128) {
		// 获取MAC的16进制字符串
		String hex = ByteUtil.strLocalToHexString(field128);
		// 获取MAC的压缩BCD字节
		byte[] byts = ByteUtil.strToBCDBytes(hex);
		// 获取MAC压缩BCD字节对应的16进制字符串
		String macHex = ByteUtil.bytesToHexString(byts);
		// 返回交易说明的16进制字符串
		return macHex;
	}

	/**
	 * 根据传入的值选择执行打包域的方法
	 * 
	 * @param pro
	 *            域(位图从0至(length -1))
	 */
	protected String process(int pro) {
		// 发送到广东省中山市建行自助圈存交易流程
		switch (pro) {
		case 0:
			return field1(bean.getBs());
		case 1:
			return field2(bean.getField2());
		case 2:
			return field3(bean.getField3());
		case 3:
			return field4(bean.getField4());
		case 6:
			return field7(bean.getField7());
		case 10:
			return field11(bean.getField11());
		case 11:
			return field12(bean.getField12());
		case 12:
			return field13(bean.getField13());
		case 14:
			return field15(bean.getField15());
		case 27:
			return field28(bean.getField28());
		case 31:
			return field32(bean.getField32());
		case 36:
			return field37(bean.getField37());
		case 40:
			return field41(bean.getField41());
		case 41:
			return field42(bean.getField42());
		case 47:
			return field48(bean.getField48());
		case 51:
			return field52(bean.getField52());
		case 99:
			return field100(bean.getField100());
		case 103:
			return field104(bean.getField104());
		case 127:
			return field128(bean.getField128());
		default:
			throw new RuntimeException();
		}
	}
	
	public static void main(String args[]){
//		System.out.println(field59("王书琪"));
	}
}
