package com.dspread.demoui.iso.Util;





import com.dspread.demoui.iso.constant.CoderConstant;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.BitSet;

/**
 * <p>
 * Description: 字节操作类
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Create Date: 2012-09-06
 * </p>
 * <p>
 * Company: HENGBAO
 * </p>
 * 
 * @author husy
 * @version $Id: ByteUtil.java,v 1.1 husy Exp $
 */
public final class ByteUtil {

	/**
	 * 根据位图位置上的true和false判断 某位置上是否存在值,如果存在则以1表示,
	 * 反之则以0表示,最终结果是:0000000011111......
	 * 
	 * @param bs
	 *            位图
	 * @return 位图的字符串形式
	 */
	public static String bitSetToBinString(BitSet bs) {
		// 获取位图总长度
		int len = bs.size();
		// 位图的字符串形式
		StringBuilder bitStr = new StringBuilder();
		// 循环获取位图的String形式
		for (int i = 0; i < len; i++) {
			if (true == bs.get(i)) {
				if (i == 0 && len == 64) { // 64位位图,位图的第一位只能为0
					bitStr.append(CoderConstant.BITSET_ZERO);
				} else {
					bitStr.append(CoderConstant.BITSET_ONE);
				}
			} else {
				bitStr.append(CoderConstant.BITSET_ZERO);
			}
		}
		return bitStr.toString();
	}

	/**
	 * 将二进制字符串转化为位图
	 * 
	 * 00001111-->BITSET
	 * 
	 * @param binStr
	 *            2进制字符串
	 * @return 位图
	 */
	public static BitSet binStringToBitSet(String binStr) {
		// 获取2进制字符串的char数组
		char[] ch = binStr.toCharArray();
		// 定义新BitSet
		BitSet bs = new BitSet(ch.length);
		// 将数据域中所有域位置置为FALSE
		bs.set(0, bs.size(), false);
		for (int i = 0; i < bs.size(); i++) {
			if (CoderConstant.BITSET_ONE.equals(String.valueOf(ch[i]))) {
				bs.set(i);
			}
		}
		// 返回位图
		return bs;
	}

	/**
	 * 字符串 111100111100-->将每一位看为byte中的一个bit 4个bit作为一个byte中的低4位,域0x0F进行"&"运算
	 * 高4位永远为0000,运算后可得 byte --> 0000 1111 , 0000 0011 ,0000 1100 以上三个字节为运算后结果
	 * ,将byte强转为int,根据数据值 获取hexStr中对应的16进制表现形式
	 * 
	 * @param binStr
	 *            二进制字符串形式
	 * @return
	 */
	public static String binStrToHexString(String binStr) {
		try {
			// 将字符串转换为字节
			byte[] bytes = binStr.getBytes("GBK");

			// 以4个0或1组成一个字节的低4位
			int realLen = bytes.length / 4;
			// 定义空字符串
			StringBuilder builder = new StringBuilder();
			// 获取单字节的低4位所对应的16进制字符
			for (int i = 0; i < realLen; i++) {
				// 4个0或1字符串为一组
				// int j = i * 4;
				// 获取字节低4位对应的数字(非负)
				int num = 0x0F & ((bytes[i * 4] << 3) | (bytes[i * 4 + 1] << 2)
						| (bytes[i * 4 + 2] << 1) | (bytes[i * 4 + 3] << 0));
				// 获取对应的16进制字符串
				builder.append(CoderConstant.hexStr[num]);
			}

			return builder.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 将16进制转换为2进制的字符串形式
	 * 
	 * F0-->1111 0000
	 * 
	 * @param hexStr
	 *            16进制字符串
	 * @return 2进制字符串
	 */
	public static String hexStringToBinStr(String hexStr) {
		// 将16进制字符串转换为char数组
		char[] ch = hexStr.toCharArray();
		// 定义新字符串
		StringBuilder builder = new StringBuilder();
		// 循环char数组,获取2进制的字符串形式
		for (int i = 0; i < ch.length; i++) {
			builder.append(CoderConstant.hexMap.get(String.valueOf(ch[i])));
		}
		return builder.toString();
	}

	private static byte toByte(char c) {
		byte b = (byte) "0123456789ABCDEF".indexOf(c);
		return b;
	}

	/**
	 * 将字符串压缩成为BCD,并以字节数组形式返回
	 * 
	 * 只接受 0123456789ABCDEF
	 * 
	 * @param field
	 *            源字符串
	 * @return 压缩BCD后的字节数组
	 */
	public static byte[] strToBCDBytes(String field) {
		try {
			field = field.toUpperCase();
			// 判断传入字符串长度是否可压缩BCD,如长度为单数则右补0
			field = field.length() % 2 == 0 ? field : field + "0";
			// 获取字符串的字节数组
			byte[] bytes = field.getBytes("GBK");
			// 定义接收压缩BCD后的字节数组
			byte[] byts = new byte[field.length() / 2];
			// 两字节进行高低位或运算
			for (int i = 0; i < bytes.length / 2; i++) {
				// int j = i * 2;
				// 判断是数字0-9或字符串A-F
				byte tempHigh = bytes[i * 2] > 0x39 ? (byte) (bytes[i * 2] - 0x37)
						: (byte) (bytes[i * 2] - 0x30);
				byte tempLow = bytes[i * 2 + 1] > 0x40 ? (byte) (bytes[i * 2 + 1] - 0x37)
						: (byte) (bytes[i * 2 + 1] - 0x30);
				// 转换后的压缩字节
				byts[i] = (byte) (tempHigh << 4 | tempLow);
			}
			// 返回压缩后BCD字节数组
			return byts;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * BCD字节数组解码转换为字符串 bcd->ascii->str
	 * 
	 * @param bytes
	 *            BCD字节数组
	 * @return 解压后的非压缩字符串表现形式
	 */
	public static String BCDBytesToStr(byte[] bytes) {
		try {
			int len = bytes.length;
			// 定义解压BCD后的新字节数组
			byte[] byts = new byte[len * 2];
			// 将压缩的BCD字节解压成两个非压缩字节
			for (int i = 0; i < len; i++) {
				// 判断是数字0-9还是字符串A-F 小于10的,加0x30,(0~9) 大于10的,加0x37,(A~Z)
				// (变小写加0x57) CHAR + 'A' - 10
				byts[i * 2] = ((bytes[i] >>> 4) & 0x0F) > 0x09 ? (byte) ((((bytes[i] >>> 4) & 0x0F) + 0x37) & 0xFF) // zimu
						: (byte) ((((bytes[i] >>> 4) & 0x0F) + 0x30) & 0xFF);
				byts[i * 2 + 1] = (bytes[i] & 0x0F) > 0x09 ? (byte) (((bytes[i] & 0x0F) + 0x37) & 0xFF)
						: (byte) (((bytes[i] & 0x0F) + 0x30) & 0xFF);
			}
			return new String(byts, "GBK");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 将字节转换为对应的16进制字符串形式
	 * 
	 * 11110000-->F0
	 * 
	 * @param bytes
	 *            字节数组
	 * @return 字节数组的16进制字符串形式
	 */
	public static String bytesToHexString(byte[] bytes) {
		// 获取字节数组长度
		int len = bytes.length;
		// 定义空字符串
		StringBuilder builder = new StringBuilder();
		// 将字节以2个16进制字符串表示
		for (int i = 0; i < len; i++) {
			builder.append(CoderConstant.hexStr[(bytes[i] >>> 4) & 0x0F]);
			builder.append(CoderConstant.hexStr[(bytes[i] & 0x0F) & 0x0F]);
		}
		return builder.toString();
	}

	/**
	 * 把字节数组转换成16进制字符串
	 * 
	 * @param bArray
	 * @return
	 */
	public static final String bytesToHexStr(byte[] bArray) {
		StringBuffer sb = new StringBuffer(bArray.length);
		String sTemp;
		for (int i = 0; i < bArray.length; i++) {
			sTemp = Integer.toHexString(0xFF & bArray[i]);
			if (sTemp.length() < 2)
				sb.append(0);
			sb.append(sTemp.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * 将16进制字符串转换为字节数组
	 * 
	 * F0-->11110000
	 * 
	 * @param field
	 *            16进制字符串
	 * @return 返回字节数组
	 */
	public static byte[] hexStringToBytes(String field) {
		// 将字符串拆分成数组
		char[] achar = field.toCharArray();
		// 获取16进制字符串长度
		int len = achar.length;
		// 定义数组长度
		byte[] result = new byte[len / 2];
		// 循环字符串将2个16进制字符串变为一个字节
		for (int i = 0; i < result.length; i++) {
			int pos = i * 2;
			result[i] = (byte) (toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
		}
		return result;
	}

	/**
	 * 将字符串本地编码转换成16进制的字符串
	 * 
	 * @param field
	 *            源字符串
	 * @return 16进制字符串
	 */
	public static String strLocalToHexString(String field) {
		// 定义新的16进制字符串
		StringBuilder builder = new StringBuilder();
		// 循环获取对应的ASCII字符串
		for (int i = 0; i < field.length(); i++) {
			// int temp = field.charAt(i);
			// 拼接16进制字符串
			builder.append(Integer.toHexString(field.charAt(i)));
		}
		return builder.toString();
	}

	/**
	 * 将16进制字符串转换成本地编码字符串
	 * 
	 * @param field
	 *            16进制字符串
	 * @return 字符串
	 */
	public static String hexStringToStrLocal(String field) {
		try {
			// 获取16进制字符串的字节
			byte[] bytes = hexStringToBytes(field);
			return new String(bytes, "GBK");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static int byteArrayToInt(byte[] b) {
		return (b[0] << 24) + ((b[1] & 0xFF) << 16) + ((b[2] & 0xFF) << 8)
				+ (b[3] & 0xFF);
	}

	/**
	 * 整型转byte数组
	 * 
	 * @param num
	 * @return byte[]
	 */
	public static byte[] int2bytes(int num) {
		byte[] b = new byte[4];
		for (int i = 0; i < 4; i++) {
			b[i] = (byte) (num >>> (24 - i * 8));
		}
		return b;
	}

	public static short byteArrayToShort(byte[] b) {
		ByteBuffer byteBuff = ByteBuffer.wrap(b);
		return byteBuff.getShort();
	}

	public static byte[] shortToBytes(short value) {
		byte[] bytes = new byte[2];
		ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
		byteBuffer.putShort(value);
		return bytes;
	}

	public static byte[] str2cbcdtemp(String s) {
		if (s.length() % 2 != 0) {
			s = "0" + s;
		}
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		char[] cs = s.toCharArray();
		for (int i = 0; i < cs.length; i += 2) {
			baos.write((cs[i] - 48) << 4 | (cs[i + 1] - 48));
		}
		return baos.toByteArray();
	}

	public static String cbcd2stringtemp(byte[] b) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < b.length; i++) {
			int h = ((b[i] & 0xff) >> 4) + 48;
			sb.append((char) h);
			int l = (b[i] & 0x0f) + 48;
			sb.append((char) l);
		}
		return sb.toString();
	}

	/**
	 * 计算报文长度,两字节报文长度(高位在前)
	 * 
	 * @param len
	 * @return
	 */
	public static byte[] getByteMessageLen(int len) {
		byte[] buf = new byte[2];
		// 取高8位
		buf[0] = (byte) (len >> 8);
		// 取低8
		buf[1] = (byte) (len & 0xff);
		return buf;
	}

	/**
	 * 计算8583表示报文前两字节长度， 如：数据 0, 115, 0, 0, 0, 0, 0, 96, 0, 0, 0, 0........
	 * 前面的0,115表示报文的长 度，获取报文长度, 两字节16进制报文长度（高位在前）, 例如300字节长报文，长度填0x012C
	 * ,变为blen[1] & 0xff 变成无符号整形
	 */
	public static int getMessageLen(byte[] blen) {
		/*
		 * for(int i=0;i<blen.length;i++){ System.out.println(blen[i]); }
		 */
		/*
		 * String hexlen = Integer.toHexString(blen[0]) +
		 * Integer.toHexString(blen[1] & 0xff);
		 */
		// System.out.println(ByteUtil.bytesToHexString(blen));
		return Integer.parseInt(ByteUtil.bytesToHexString(blen), 16);
	}

	/**
	 * @函数功能: 10进制串转为BCD码
	 * @输入参数: 10进制串
	 * @输出结果: BCD码
	 */
	public static byte[] str2Bcd(String asc) {
		int len = asc.length();
		int mod = len % 2;

		if (mod != 0) {
			asc = "0" + asc;
			len = asc.length();
		}

		byte abt[] = new byte[len];
		if (len >= 2) {
			len = len / 2;
		}

		byte bbt[] = new byte[len];
		abt = asc.getBytes();
		int j, k;

		for (int p = 0; p < asc.length() / 2; p++) {
			if ((abt[2 * p] >= '0') && (abt[2 * p] <= '9')) {
				j = abt[2 * p] - '0';
			} else if ((abt[2 * p] >= 'a') && (abt[2 * p] <= 'z')) {
				j = abt[2 * p] - 'a' + 0x0a;
			} else {
				j = abt[2 * p] - 'A' + 0x0a;
			}

			if ((abt[2 * p + 1] >= '0') && (abt[2 * p + 1] <= '9')) {
				k = abt[2 * p + 1] - '0';
			} else if ((abt[2 * p + 1] >= 'a') && (abt[2 * p + 1] <= 'z')) {
				k = abt[2 * p + 1] - 'a' + 0x0a;
			} else {
				k = abt[2 * p + 1] - 'A' + 0x0a;
			}

			int a = (j << 4) + k;
			byte b = (byte) a;
			bbt[p] = b;
		}
		return bbt;
	}

	public static String bcd2Str(byte[] bytes) {
		char temp[] = new char[bytes.length * 2], val;

		for (int i = 0; i < bytes.length; i++) {
			val = (char) (((bytes[i] & 0xf0) >> 4) & 0x0f);
			temp[i * 2] = (char) (val > 9 ? val + 'A' - 10 : val + '0');

			val = (char) (bytes[i] & 0x0f);
			temp[i * 2 + 1] = (char) (val > 9 ? val + 'A' - 10 : val + '0');
		}
		return new String(temp);
	}

	/**
	 * 把字节数组转换为对象
	 * 
	 * @param bytes
	 * @return
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static final Object bytesToObject(byte[] bytes) throws IOException,
			ClassNotFoundException {
		ByteArrayInputStream in = new ByteArrayInputStream(bytes);
		ObjectInputStream oi = new ObjectInputStream(in);
		Object o = oi.readObject();
		oi.close();
		return o;
	}

	/**
	 * 把可序列化对象转换成字节数组
	 * 
	 * @param s
	 * @return
	 * @throws IOException
	 */
	public static final byte[] objectToBytes(Serializable s) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ObjectOutputStream ot = new ObjectOutputStream(out);
		ot.writeObject(s);
		ot.flush();
		ot.close();
		return out.toByteArray();
	}

	public static final String objectToHexString(Serializable s)
			throws IOException {
		return bytesToHexString(objectToBytes(s));
	}

	public static final Object hexStringToObject(String hex)
			throws IOException, ClassNotFoundException {
		return bytesToObject(hexStringToBytes(hex));
	}

	/**
	 * MD5加密字符串，返回加密后的16进制字符串
	 * 
	 * @param origin
	 * @return
	 */
	public static String MD5EncodeToHex(String origin) {
		return bytesToHexString(MD5Encode(origin));
	}

	/**
	 * MD5加密字符串，返回加密后的字节数组
	 * 
	 * @param origin
	 * @return
	 */
	public static byte[] MD5Encode(String origin) {
		return MD5Encode(origin.getBytes());
	}

	/**
	 * MD5加密字节数组，返回加密后的字节数组
	 * 
	 * @param bytes
	 * @return
	 */
	public static byte[] MD5Encode(byte[] bytes) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
			return md.digest(bytes);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return new byte[0];
		}

	}

	public static void main(String[] args) {
		// byte[] bytes = str2cbcdtemp("消费修正");
		// for (int i = 0; i < bytes.length; i++) {
		// System.out.println(bytes[i]);
		// }
		// System.out.println(strLocalToHexString("挂失补卡"));
		// System.out.println(Integer.parseInt("6302", 16));
		// String s = BCDBytesToStr(bytes);6302593188655361
		// System.out.println(s);
		// byte[] b = {1,15};
		// System.out.println(StringUtils.toStringHex("AB9223B9E7DEC138","GBK"));
		byte[] byts= str2Bcd("26");
		for(byte s : byts){
		System.out.println(s);
		}
		
	}



	/**
	 *
	 * @param hexString
	 * @return 将十六进制转换为二进制数组
	 */
	public static BitSet hexStringToBitSet(String hexString){
		//一位16进制数占用4位
		BitSet bitSet = new BitSet(hexString.length()*4);

		for(int i=0;i<hexString.length();i++){
			for(int j=0;j<4;j++){
				if((0x1 & (Integer.parseInt(hexString.substring(i, i+1), 16) >> 4-1-j)) == 0x1){
					bitSet.set(i*4+j, true);
				}
			}
		}

		return bitSet;
	}
}
