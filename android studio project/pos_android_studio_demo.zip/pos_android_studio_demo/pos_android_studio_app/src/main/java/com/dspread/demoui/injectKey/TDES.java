package com.dspread.demoui.injectKey;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class TDES {
    public TDES() {
    }

    public static byte[] desEncypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DES/ECB/NoPadding", new BouncyCastleProvider());
        cipher.init(1, key);
        byte[] cipherText = new byte[cipher.getOutputSize(input.length)];
        int ctLength = cipher.update(input, 0, input.length, cipherText, 0);
        ctLength += cipher.doFinal(cipherText, ctLength);
        return cipherText;
    }

    public static byte[] desDecrypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DES/ECB/NoPadding", new BouncyCastleProvider());
        cipher.init(2, key);
        byte[] plainText = new byte[cipher.getOutputSize(input.length)];
        int ptLength = cipher.update(input, 0, input.length, plainText, 0);
        ptLength += cipher.doFinal(plainText, ptLength);
        return plainText;
    }

    public static byte[] tdesEncypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding", new BouncyCastleProvider());
        cipher.init(1, key);
        byte[] cipherText = new byte[cipher.getOutputSize(input.length)];
        int ctLength = cipher.update(input, 0, input.length, cipherText, 0);
        ctLength += cipher.doFinal(cipherText, ctLength);
        return cipherText;
    }

    public static byte[] tdesDecrypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding", new BouncyCastleProvider());
        cipher.init(2, key);
        byte[] plainText = new byte[cipher.getOutputSize(input.length)];
        int ptLength = cipher.update(input, 0, input.length, plainText, 0);
        ptLength += cipher.doFinal(plainText, ptLength);
        return plainText;
    }

    public static byte[] tdesCBCEncypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DESede/CBC/NoPadding", new BouncyCastleProvider());
        byte[] iv = new byte[8];
        cipher.init(1, key, new IvParameterSpec(iv));
        byte[] cipherText = new byte[cipher.getOutputSize(input.length)];
        cipherText = cipher.doFinal(input);
        return cipherText;
    }

    public static byte[] tdesCBCDecrypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DESede/CBC/NoPadding", new BouncyCastleProvider());
        byte[] iv = new byte[8];
        cipher.init(2, key, new IvParameterSpec(iv));
        byte[] plainText = new byte[cipher.getOutputSize(input.length)];
        int ptLength = cipher.update(input, 0, input.length, plainText, 0);
        ptLength += cipher.doFinal(plainText, ptLength);
        return plainText;
    }

    public static byte[] tdesECBEncypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding", new BouncyCastleProvider());
        cipher.init(1, key);
        byte[] cipherText = new byte[cipher.getOutputSize(input.length)];
        int ctLength = cipher.update(input, 0, input.length, cipherText, 0);
        ctLength += cipher.doFinal(cipherText, ctLength);
        return cipherText;
    }

    public static byte[] tdesECBDecrypt(byte[] keyBytes, byte[] input) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES");
        Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding", new BouncyCastleProvider());
        cipher.init(2, key);
        byte[] plainText = new byte[cipher.getOutputSize(input.length)];
        int ptLength = cipher.update(input, 0, input.length, plainText, 0);
        ptLength += cipher.doFinal(plainText, ptLength);
        return plainText;
    }

    public static void main(String[] args) {
        byte[] input = new byte[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7};
        byte[] deskeyBytes = new byte[]{1, 35, 69, 103, -119, -85, -51, -17};
        byte[] tdeskeyBytes = new byte[]{1, 35, 69, 103, -119, -85, -51, -17, 1, 35, 69, 103, -119, -85, -51, -17};

        try {
            byte[] e = desEncypt(deskeyBytes, input);
            System.out.println("des_cipher : " + Utils.toHex(e, e.length) + " bytes: " + e.length);
            byte[] de = desDecrypt(deskeyBytes, e);
            System.out.println("des_plain : " + Utils.toHex(de, de.length) + " bytes: " + de.length);
            e = tdesEncypt(tdeskeyBytes, input);
            System.out.println("des_cipher : " + Utils.toHex(e, e.length) + " bytes: " + e.length);
            de = tdesDecrypt(tdeskeyBytes, e);
            System.out.println("des_plain : " + Utils.toHex(de, de.length) + " bytes: " + de.length);
            e = tdesCBCEncypt(tdeskeyBytes, input);
            System.out.println("cbc_des_cipher : " + Utils.toHex(e, e.length) + " bytes: " + e.length);
            de = tdesCBCDecrypt(tdeskeyBytes, e);
            System.out.println("cbc_des_plain : " + Utils.toHex(de, de.length) + " bytes: " + de.length);
            byte[] ipenen = new byte[]{-109, -42, 125, 98, 51, 123, 54, -16, -41, 57, 102, 60, -85, -18, -3, 60};
            byte[] tmk = new byte[]{95, -117, 43, -120, 24, -106, 108, 92, -44, -52, 57, 58, -7, -4, 119, 34};
            e = tdesECBEncypt(tmk, ipenen);
            System.out.println("ecb_des_cipher : " + Utils.toHex(e, e.length) + " bytes: " + e.length);
            de = tdesECBDecrypt(tmk, ipenen);
            System.out.println("ecb_des_plain : " + Utils.toHex(de, de.length) + " bytes: " + de.length);
        } catch (Exception var8) {
            var8.printStackTrace();
        }

    }
}
