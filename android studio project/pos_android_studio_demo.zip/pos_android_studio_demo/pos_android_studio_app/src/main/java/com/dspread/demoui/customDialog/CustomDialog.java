package com.dspread.demoui.customDialog;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.dspread.demoui.R;

/**
 * Created by dell on 2018/1/12.
 */

public class CustomDialog {

    private View view;
    private Dialog dialog;
    private TextView title;
    private TextView message;
    private TextView cancel;
    private TextView ok;
    private RelativeLayout messageContainer;
    private LinearLayout titleContainer;
    private Context mContext;
    private LinearLayout bottomBtn;

    public CustomDialog(Context context) {
        mContext = context;
        dialog = new Dialog(context);
        view = LayoutInflater.from(context).inflate(R.layout.view_alert_dialog,null);
        initView();
        initListener();
        initDia();
    }

    private CusDialogClickListener cusDialogClickListener;

    public void setCusDialogClickListener(CusDialogClickListener cusDialogClickListener) {
        this.cusDialogClickListener = cusDialogClickListener;
    }


    private void initDia() {
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(view);
    }

    private void initListener() {
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cusDialogClickListener!=null)
                {
                    cusDialogClickListener.buttonCancel(dialog);
                }
                dismissDialog();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cusDialogClickListener!=null)
                {
                    boolean b = cusDialogClickListener.buttonOk(dialog);
                    if (!b){
                        return;
                    }
                }
                dismissDialog();
            }
        });
    }


    private void initView() {
        title = ((TextView) view.findViewById(R.id.dialog_title));
        message = ((TextView) view.findViewById(R.id.dialog_message));
        cancel = ((TextView) view.findViewById(R.id.dialog_cancel));
        ok = (TextView)view.findViewById(R.id.dialog_ok);
        messageContainer = ((RelativeLayout) view.findViewById(R.id.dialog_message_container));
        titleContainer = ((LinearLayout) view.findViewById(R.id.dialog_title_container));
        bottomBtn = ((LinearLayout) view.findViewById(R.id.bottom_btn));


    }

    public void hideBottomCon() {
        if (bottomBtn!=null){
            bottomBtn.setVisibility(View.GONE);
        }
    }

    public void showBottomCon() {
        if (bottomBtn!=null){
            bottomBtn.setVisibility(View.VISIBLE);
        }
    }


    public void setTitle(String msg)
    {
        if(title!=null)
        {
            if(!TextUtils.isEmpty(msg))
            {
                title.setText(msg);
                dialog.setTitle(msg);
            }
        }
    }

    public void setMessage(String msg)
    {
        if(message!=null)
        {
            if(!TextUtils.isEmpty(msg))
            {
                message.setText(msg);
            }
        }
    }

    public void setOkButtonText(String msg)
    {
        if(ok!=null)
        {
            if(!TextUtils.isEmpty(msg))
            {
                ok.setText(msg);
            }
        }
    }

    public void setCancelButtonText(String msg)
    {
        if(cancel!=null)
        {
            if(!TextUtils.isEmpty(msg))
            {
                cancel.setText(msg);
            }
        }
    }


    public void showDia(){
        if (dialog!=null&&dialog.isShowing()){
            dialog.dismiss();
        }
        dialog.show();
        //放在show()之后，不然有些属性是没有效果的，比如height和width
        Window dialogWindow = dialog.getWindow();
        WindowManager m =  (WindowManager)mContext.getSystemService(Context.WINDOW_SERVICE);
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams p = dialogWindow.getAttributes(); // 获取对话框当前的参数值
//设置高度和宽度
        p.height = p.WRAP_CONTENT; // 高度设置为屏幕的0.6
        p.width = (int) (d.getWidth() * 270/375); // 宽度设置为屏幕的0.65
//设置位置
        p.gravity = Gravity.CENTER;
//设置透明度
//        p.alpha = 0.5f;
        dialogWindow.setAttributes(p);
    }

    public void dismissDialog()
    {
        if(dialog!=null && dialog.isShowing())
        {
            dialog.dismiss();
        }
    }


    public void setCusTitleView(View titleView)
    {
        if (titleContainer!=null && titleView!=null) {
            titleContainer.removeAllViews();
            titleContainer.addView(titleView);
        }
    }

    /**
     * 设置自定已contentView
     * @param view
     */
    public void setCusContentView(View view)
    {
        if(view!=null)
        {
            messageContainer.removeAllViews();
            messageContainer.addView(view);
        }
    }
}
