package com.dspread.demoui.utils;

/**
 * Created by dsppc11 on 2018/7/25.
 */

interface Constatns {
   String EMV_UPDATE_STATUS = "emv_update_status";
   String HAS_EMV_READ_STATUS = "has_emv_read_status";
}
