/** Automatically generated file. DO NOT MODIFY */
package com.dspread.demoui.pagptodo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}